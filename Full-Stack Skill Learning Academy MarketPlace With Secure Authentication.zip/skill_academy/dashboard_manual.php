<?php
require_once 'config/db.php';
require_once 'config/auth.php';

// Check if user is logged in
requireLogin();

// Get current user data
$currentUser = getCurrentUser();

if (!$currentUser) {
    header('Location: login.php');
    exit;
}

// Get user enrollments with course details
$stmt = $conn->prepare("
    SELECT c.*, e.completed, e.enrolled_at
    FROM courses c
    LEFT JOIN enrollments e ON c.id = e.course_id AND e.user_id = ?
    ORDER BY c.level, c.title
");
$stmt->bind_param("i", $currentUser['id']);
$stmt->execute();
$courses = $stmt->get_result();

// Get user statistics
$totalCourses = 0;
$completedCourses = 0;
$enrolledCourses = 0;

while ($course = $courses->fetch_assoc()) {
    $totalCourses++;
    if ($course['completed']) {
        $completedCourses++;
    }
    if ($course['enrolled_at']) {
        $enrolledCourses++;
    }
}

// Reset result pointer for later use
$courses->data_seek(0);

// Check user access permissions
$hasPremium = hasPremium($conn, $currentUser['id']);
$completedAllBasics = completedAllBasics($conn, $currentUser['id']);
$canAccessAdvanced = $completedAllBasics && $hasPremium;

// Get progress percentage
$progressPercentage = $totalCourses > 0 ? round(($completedCourses / $totalCourses) * 100) : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Skill Academy</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-brand">
                <h1>Skill Academy</h1>
            </div>
            <div class="nav-menu">
                <span class="nav-user">Welcome, <?php echo htmlspecialchars($currentUser['name']); ?></span>
                <?php if ($hasPremium): ?>
                    <span class="premium-badge">PREMIUM</span>
                <?php endif; ?>
                <a href="index.php" class="nav-link">Home</a>
                <button id="logoutBtn" class="btn btn-outline">Logout</button>
            </div>
        </div>
    </nav>

    <!-- Dashboard Header -->
    <section class="dashboard-header">
        <div class="container">
            <div class="dashboard-welcome">
                <h1>Welcome back, <?php echo htmlspecialchars($currentUser['name']); ?>!</h1>
                <p>Track your learning progress and continue your journey</p>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats-section">
        <div class="container">
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $completedCourses; ?></div>
                    <div class="stat-label">Completed Courses</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $enrolledCourses; ?></div>
                    <div class="stat-label">Enrolled Courses</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $progressPercentage; ?>%</div>
                    <div class="stat-label">Overall Progress</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $hasPremium ? '✓' : '✗'; ?></div>
                    <div class="stat-label">Premium Status</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Progress Bar -->
    <section class="progress-section">
        <div class="container">
            <div class="progress-container">
                <div class="progress-header">
                    <h3>Your Learning Progress</h3>
                    <span class="progress-text"><?php echo $completedCourses; ?> of <?php echo $totalCourses; ?> courses completed</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: <?php echo $progressPercentage; ?>%"></div>
                </div>
            </div>
        </div>
    </section>

    <!-- Courses Section -->
    <section class="dashboard-courses">
        <div class="container">
            <div class="section-header">
                <h2>Your Courses</h2>
                <p>Manage your enrolled courses and track your progress</p>
            </div>

            <!-- Basic Courses -->
            <div class="course-section">
                <h3>Basic Courses</h3>
                <div class="courses-grid">
                    <?php 
                    $courses->data_seek(0);
                    while ($course = $courses->fetch_assoc()): 
                        if ($course['level'] !== 'basic') continue;
                    ?>
                        <div class="course-card dashboard-card">
                            <div class="course-image">
                                <img src="assets/images/<?php echo htmlspecialchars($course['image']); ?>" alt="<?php echo htmlspecialchars($course['title']); ?>">
                                <?php if ($course['completed']): ?>
                                    <div class="completed-overlay">
                                        <i class="check-icon">✓</i>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="course-content">
                                <h4><?php echo htmlspecialchars($course['title']); ?></h4>
                                <p><?php echo htmlspecialchars($course['description']); ?></p>
                                
                                <div class="course-status">
                                    <?php if ($course['completed']): ?>
                                        <span class="status-badge completed">Completed</span>
                                    <?php elseif ($course['enrolled_at']): ?>
                                        <span class="status-badge in-progress">In Progress</span>
                                    <?php else: ?>
                                        <span class="status-badge not-started">Not Started</span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="course-actions">
                                    <?php if ($course['completed']): ?>
                                        <button class="btn btn-success" disabled>
                                            <i class="check-icon">✓</i> Completed
                                        </button>
                                    <?php elseif ($course['enrolled_at']): ?>
                                        <button class="btn btn-primary" onclick="markComplete(<?php echo $course['id']; ?>)">
                                            Mark as Complete
                                        </button>
                                    <?php else: ?>
                                        <a href="enroll.php?course_id=<?php echo $course['id']; ?>" class="btn btn-primary">Start Course</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>

            <!-- Advanced Courses -->
            <div class="course-section">
                <h3>Advanced Courses</h3>
                <?php if (!$canAccessAdvanced): ?>
                    <div class="access-notice">
                        <div class="notice-content">
                            <h4>🔒 Advanced Courses Locked</h4>
                            <p>You need to complete all basic courses and have a premium membership to access advanced courses.</p>
                            <div class="notice-requirements">
                                <div class="requirement <?php echo $completedAllBasics ? 'met' : 'unmet'; ?>">
                                    <span class="requirement-icon"><?php echo $completedAllBasics ? '✓' : '○'; ?></span>
                                    Complete all basic courses
                                </div>
                                <div class="requirement <?php echo $hasPremium ? 'met' : 'unmet'; ?>">
                                    <span class="requirement-icon"><?php echo $hasPremium ? '✓' : '○'; ?></span>
                                    Have premium membership
                                </div>
                            </div>
                            <?php if ($completedAllBasics && !$hasPremium): ?>
                                <a href="premium.php" class="btn btn-primary">Upgrade to Premium</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="courses-grid">
                    <?php 
                    $courses->data_seek(0);
                    while ($course = $courses->fetch_assoc()): 
                        if ($course['level'] !== 'advanced') continue;
                        
                        $isLocked = !$canAccessAdvanced;
                    ?>
                        <div class="course-card dashboard-card <?php echo $isLocked ? 'locked' : ''; ?>">
                            <div class="course-image">
                                <img src="assets/images/<?php echo htmlspecialchars($course['image']); ?>" alt="<?php echo htmlspecialchars($course['title']); ?>">
                                <?php if ($isLocked): ?>
                                    <div class="lock-overlay">
                                        <i class="lock-icon">🔒</i>
                                    </div>
                                <?php elseif ($course['completed']): ?>
                                    <div class="completed-overlay">
                                        <i class="check-icon">✓</i>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="course-content">
                                <h4><?php echo htmlspecialchars($course['title']); ?></h4>
                                <p><?php echo htmlspecialchars($course['description']); ?></p>
                                
                                <div class="course-status">
                                    <?php if ($isLocked): ?>
                                        <span class="status-badge locked">Locked</span>
                                    <?php elseif ($course['completed']): ?>
                                        <span class="status-badge completed">Completed</span>
                                    <?php elseif ($course['enrolled_at']): ?>
                                        <span class="status-badge in-progress">In Progress</span>
                                    <?php else: ?>
                                        <span class="status-badge not-started">Not Started</span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="course-actions">
                                    <?php if ($isLocked): ?>
                                        <button class="btn btn-disabled" disabled>
                                            <i class="lock-icon">🔒</i> Locked
                                        </button>
                                    <?php elseif ($course['completed']): ?>
                                        <button class="btn btn-success" disabled>
                                            <i class="check-icon">✓</i> Completed
                                        </button>
                                    <?php elseif ($course['enrolled_at']): ?>
                                        <button class="btn btn-primary" onclick="markComplete(<?php echo $course['id']; ?>)">
                                            Mark as Complete
                                        </button>
                                    <?php else: ?>
                                        <a href="enroll.php?course_id=<?php echo $course['id']; ?>" class="btn btn-primary">Start Course</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- Success Modal -->
    <div id="successModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>🎉 Congratulations!</h3>
                <span class="modal-close">&times;</span>
            </div>
            <div class="modal-body">
                <p>Course marked as completed successfully!</p>
            </div>
        </div>
    </div>

    <script>
        // Logout functionality
        document.getElementById('logoutBtn').addEventListener('click', function() {
            if (confirm('Are you sure you want to logout?')) {
                window.location.href = 'logout.php';
            }
        });

        // Mark course as complete
        function markComplete(courseId) {
            if (confirm('Are you sure you want to mark this course as completed?')) {
                fetch('mark_complete.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        course_id: courseId
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Show success modal
                        document.getElementById('successModal').style.display = 'block';
                        // Reload page after 2 seconds
                        setTimeout(() => {
                            window.location.reload();
                        }, 2000);
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred. Please try again.');
                });
            }
        }

        // Modal close functionality
        document.addEventListener('DOMContentLoaded', function() {
            const modal = document.getElementById('successModal');
            const closeBtn = document.querySelector('.modal-close');
            
            if (closeBtn) {
                closeBtn.onclick = function() {
                    modal.style.display = 'none';
                }
            }
            
            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = 'none';
                }
            }
        });
    </script>
</body>
</html>
