<?php
require_once 'config/db.php';
require_once 'config/auth.php';

header('Content-Type: application/json');

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get and validate input
$email = sanitizeInput($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$remember = isset($_POST['remember']) ? $_POST['remember'] : false;

// CSRF protection
if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    echo json_encode(['success' => false, 'message' => 'Invalid request token']);
    exit;
}

// Rate limiting
if (!checkRateLimit($email)) {
    echo json_encode(['success' => false, 'message' => 'Too many login attempts. Please try again later.']);
    exit;
}

// Validate input
if (empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Email and password are required']);
    exit;
}

if (!validateEmail($email)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email address']);
    exit;
}

try {
    // Check if user is locked out
    $stmt = $conn->prepare("SELECT locked_until FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $lockedUntil = $user['locked_until'];
        
        if ($lockedUntil && strtotime($lockedUntil) > time()) {
            echo json_encode(['success' => false, 'message' => 'Account temporarily locked. Please try again later.']);
            exit;
        }
    }
    
    // Get user by email
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        // Log failed attempt
        logLoginAttempt($email, false);
        echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
        exit;
    }
    
    $user = $result->fetch_assoc();
    
    // Verify password
    if (!verifyPassword($password, $user['password_hash'])) {
        // Increment login attempts
        incrementLoginAttempts($user['id']);
        
        // Log failed attempt
        logLoginAttempt($email, false);
        
        echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
        exit;
    }
    
    // Check if email is verified (skip for demo)
    if (!$user['email_verified']) {
        echo json_encode(['success' => false, 'message' => 'Please verify your email address first']);
        exit;
    }
    
    // Reset login attempts on successful login
    resetLoginAttempts($user['id']);
    
    // Update last login
    $updateStmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
    $updateStmt->bind_param("i", $user['id']);
    $updateStmt->execute();
    
    // Check premium status
    $premiumStmt = $conn->prepare("SELECT COUNT(*) as count FROM premium_memberships WHERE user_id = ?");
    $premiumStmt->bind_param("i", $user['id']);
    $premiumStmt->execute();
    $premiumResult = $premiumStmt->get_result();
    $premiumRow = $premiumResult->fetch_assoc();
    $user['has_premium'] = $premiumRow['count'] > 0;
    
    // Create user session
    $sessionData = [
        'id' => $user['id'],
        'name' => $user['name'],
        'email' => $user['email'],
        'has_premium' => $user['has_premium']
    ];
    
    loginUser($sessionData);
    
    // Store session in database for enhanced security
    $sessionId = session_id();
    $sessionStmt = $conn->prepare("
        INSERT INTO user_sessions (user_id, session_id, ip_address, user_agent, expires_at) 
        VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
        ip_address = VALUES(ip_address),
        user_agent = VALUES(user_agent),
        expires_at = VALUES(expires_at),
        is_active = TRUE
    ");
    $expiresAt = date('Y-m-d H:i:s', time() + ($remember ? REMEMBER_LIFETIME : SESSION_LIFETIME));
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
    $sessionStmt->bind_param("issss", $user['id'], $sessionId, $ipAddress, $userAgent, $expiresAt);
    $sessionStmt->execute();
    
    // Log successful login
    logLoginAttempt($email, true);
    
    echo json_encode([
        'success' => true, 
        'message' => 'Login successful! Redirecting to dashboard...',
        'user' => $sessionData
    ]);
    
} catch (Exception $e) {
    error_log("Login error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred. Please try again.']);
}

$stmt->close();
$conn->close();

// Helper functions
function logLoginAttempt($email, $success) {
    global $conn;
    $stmt = $conn->prepare("
        INSERT INTO login_attempts (email, ip_address, user_agent, success) 
        VALUES (?, ?, ?, ?)
    ");
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
    $stmt->bind_param("sssi", $email, $ipAddress, $userAgent, $success);
    $stmt->execute();
}

function incrementLoginAttempts($userId) {
    global $conn;
    $stmt = $conn->prepare("
        UPDATE users SET 
            login_attempts = login_attempts + 1,
            locked_until = CASE 
                WHEN login_attempts >= 4 THEN DATE_ADD(NOW(), INTERVAL 30 MINUTE)
                ELSE locked_until 
            END
        WHERE id = ?
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
}

function resetLoginAttempts($userId) {
    global $conn;
    $stmt = $conn->prepare("
        UPDATE users SET 
            login_attempts = 0,
            locked_until = NULL
        WHERE id = ?
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
}
?>
