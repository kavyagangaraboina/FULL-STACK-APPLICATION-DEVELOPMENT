<?php
session_start();
require_once 'config/db.php';

header('Content-Type: application/json');

// Get the posted data
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['idToken']) || !isset($data['email']) || !isset($data['name'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

$idToken = $data['idToken'];
$email = $data['email'];
$name = $data['name'];

// Verify Firebase ID token using Python Admin SDK
function verifyFirebaseTokenWithPython($idToken) {
    // Try different Python commands
    $pythonCommands = ['python', 'python3'];
    $output = null;
    
    foreach ($pythonCommands as $pythonCmd) {
        $command = escapeshellcmd("$pythonCmd verify_token_admin.py " . escapeshellarg($idToken));
        $output = shell_exec($command);
        
        if ($output !== null && !empty($output)) {
            break;
        }
    }
    
    if ($output === null) {
        return null;
    }
    
    $result = json_decode($output, true);
    
    if ($result && isset($result['success']) && $result['success']) {
        return $result['user'];
    }
    
    return null;
}

// Verify the token
$tokenData = verifyFirebaseTokenWithPython($idToken);

if ($tokenData === null) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

// Verify email matches token
if ($tokenData['email'] !== $email) {
    echo json_encode(['success' => false, 'message' => 'Email does not match token']);
    exit;
}

// Check if user already exists
$stmt = $conn->prepare("SELECT id FROM users WHERE firebase_uid = ? OR email = ?");
$stmt->bind_param("ss", $tokenData['uid'], $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'User already exists']);
    exit;
}

// Create new user
$stmt = $conn->prepare("INSERT INTO users (firebase_uid, name, email) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $tokenData['uid'], $name, $email);

if ($stmt->execute()) {
    $userId = $conn->insert_id;
    $user = [
        'id' => $userId,
        'firebase_uid' => $tokenData['uid'],
        'name' => $name,
        'email' => $email,
        'has_premium' => false
    ];
    
    // Store in PHP session as backup
    $_SESSION['userSession'] = json_encode($user);
    
    echo json_encode(['success' => true, 'user' => $user, 'message' => 'Registration successful']);
} else {
    echo json_encode(['success' => false, 'message' => 'Registration failed']);
}

$stmt->close();
$conn->close();
?>
