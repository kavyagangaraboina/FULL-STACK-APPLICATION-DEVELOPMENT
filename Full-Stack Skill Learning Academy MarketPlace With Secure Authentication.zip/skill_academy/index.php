<?php
session_start();
require_once 'config/db.php';

// Check if user is logged in
$userSession = isset($_SESSION['userSession']) ? $_SESSION['userSession'] : null;
$currentUser = null;

if ($userSession) {
    $currentUser = json_decode($userSession, true);
}

// Get all courses
$stmt = $conn->prepare("SELECT * FROM courses ORDER BY level, title");
$stmt->execute();
$courses = $stmt->get_result();

// Get user enrollments if logged in
$userEnrollments = [];
if ($currentUser) {
    $stmt = $conn->prepare("
        SELECT e.course_id, e.completed 
        FROM enrollments e 
        WHERE e.user_id = ?
    ");
    $stmt->bind_param("i", $currentUser['id']);
    $stmt->execute();
    $enrollmentResult = $stmt->get_result();
    
    while ($row = $enrollmentResult->fetch_assoc()) {
        $userEnrollments[$row['course_id']] = $row['completed'];
    }
}

// Check user access permissions
$canAccessAdvanced = false;
$completedAllBasics = false;
$hasPremium = false;

if ($currentUser) {
    $hasPremium = hasPremium($conn, $currentUser['id']);
    $completedAllBasics = completedAllBasics($conn, $currentUser['id']);
    $canAccessAdvanced = $completedAllBasics && $hasPremium;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Skill Academy - Learn New Skills</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-brand">
                <h1>Skill Academy</h1>
            </div>
            <div class="nav-menu">
                <?php if ($currentUser): ?>
                    <span class="nav-user">Welcome, <?php echo htmlspecialchars($currentUser['name']); ?></span>
                    <?php if ($hasPremium): ?>
                        <span class="premium-badge">PREMIUM</span>
                    <?php endif; ?>
                    <a href="dashboard.php" class="nav-link">Dashboard</a>
                    <button id="logoutBtn" class="btn btn-outline">Logout</button>
                <?php else: ?>
                    <a href="login_firebase.php" class="nav-link">Login</a>
                    <a href="register_firebase.php" class="btn btn-primary">Sign Up</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-container">
            <div class="hero-content">
                <h1>Master New Skills Today</h1>
                <p>Learn from expert instructors with our comprehensive courses in web development and programming.</p>
                <?php if (!$currentUser): ?>
                    <div class="hero-buttons">
                        <a href="register_firebase.php" class="btn btn-primary btn-large">Get Started Free</a>
                        <a href="#courses" class="btn btn-outline btn-large">Browse Courses</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Courses Section -->
    <section id="courses" class="courses">
        <div class="container">
            <div class="section-header">
                <h2>Our Courses</h2>
                <p>Choose from our selection of beginner and advanced courses</p>
            </div>

            <div class="courses-grid">
                <?php while ($course = $courses->fetch_assoc()): ?>
                    <?php
                    $isEnrolled = isset($userEnrollments[$course['id']]);
                    $isCompleted = $isEnrolled && $userEnrollments[$course['id']];
                    $isLocked = $course['level'] === 'advanced' && !$canAccessAdvanced;
                    ?>
                    
                    <div class="course-card <?php echo $isLocked ? 'locked' : ''; ?>">
                        <div class="course-image">
                            <img src="assets/images/<?php echo htmlspecialchars($course['image']); ?>" alt="<?php echo htmlspecialchars($course['title']); ?>">
                            <?php if ($isLocked): ?>
                                <div class="lock-overlay">
                                    <i class="lock-icon">🔒</i>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="course-content">
                            <h3><?php echo htmlspecialchars($course['title']); ?></h3>
                            <p><?php echo htmlspecialchars($course['description']); ?></p>
                            
                            <div class="course-meta">
                                <span class="course-level <?php echo $course['level']; ?>">
                                    <?php echo ucfirst($course['level']); ?>
                                </span>
                                <?php if ($isCompleted): ?>
                                    <span class="completed-badge">✓ Completed</span>
                                <?php elseif ($isEnrolled): ?>
                                    <span class="enrolled-badge">In Progress</span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="course-actions">
                                <?php if ($isLocked): ?>
                                    <button class="btn btn-disabled" disabled>
                                        <i class="lock-icon">🔒</i> Locked
                                    </button>
                                    <a href="premium.php" class="btn btn-outline">Upgrade to Premium</a>
                                <?php elseif ($isCompleted): ?>
                                    <button class="btn btn-success" disabled>
                                        <i class="check-icon">✓</i> Completed
                                    </button>
                                <?php elseif ($isEnrolled): ?>
                                    <a href="course.php?course_id=<?php echo $course['id']; ?>" class="btn btn-primary">Continue Learning</a>
                                    <a href="unenroll.php?course_id=<?php echo $course['id']; ?>" class="btn btn-outline btn-small" onclick="return confirm('Are you sure you want to unenroll from this course?')">
                                        Unenroll
                                    </a>
                                <?php elseif (!$currentUser): ?>
                                    <a href="login_firebase.php" class="btn btn-primary">Login to Enroll</a>
                                <?php else: ?>
                                    <a href="enroll.php?course_id=<?php echo $course['id']; ?>" class="btn btn-primary">Start Course</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features">
        <div class="container">
            <div class="section-header">
                <h2>Why Choose Skill Academy?</h2>
            </div>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">📚</div>
                    <h3>Expert Content</h3>
                    <p>Learn from industry experts with carefully crafted curriculum</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🎯</div>
                    <h3>Structured Learning</h3>
                    <p>Follow a clear path from basics to advanced topics</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🏆</div>
                    <h3>Track Progress</h3>
                    <p>Monitor your learning journey and celebrate achievements</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Skill Academy</h3>
                    <p>Empowering learners worldwide with quality education.</p>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="#courses">Courses</a></li>
                        <?php if ($currentUser): ?>
                            <li><a href="dashboard.php">Dashboard</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 Skill Academy. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script type="module" src="firebase_config.js"></script>
    <?php if ($currentUser): ?>
        <script type="module" src="assets/js/script.js"></script>
    <?php endif; ?>
</body>
</html>
