# Course Images

Add your course images to this directory. Required images:

- html.jpg (for HTML Fundamentals course)
- css.jpg (for CSS Mastery course)
- javascript.jpg (for JavaScript Basics course)
- advanced-js.jpg (for Advanced JavaScript course)
- fullstack.jpg (for Full Stack Development course)
- ml.jpg (for Machine Learning Foundations course)

Recommended image size: 800x600 pixels
Format: JPG or PNG

You can use placeholder images from any source or create your own course-related images.
