# Apache Setup Instructions for Skill Academy

## Quick Setup Guide

### Option 1: Using XAMPP/WAMP (Recommended for Windows)

1. **Install XAMPP** if not already installed
2. **Start Apache and MySQL** from XAMPP Control Panel
3. **Copy project to htdocs**:
   ```
   Copy entire skill_academy folder to: C:/xampp/htdocs/
   ```
4. **Access via browser**:
   ```
   http://localhost/skill_academy/
   ```

### Option 2: Configure Apache DocumentRoot

1. **Edit Apache config** (httpd.conf):
   ```apache
   DocumentRoot "c:/Users/Admin/Desktop/mansoor/mansoor/skill_academy"
   <Directory "c:/Users/Admin/Desktop/mansoor/mansoor/skill_academy">
       Options Indexes FollowSymLinks
       AllowOverride All
       Require all granted
   </Directory>
   ```

2. **Restart Apache**

3. **Access via browser**:
   ```
   http://localhost/
   ```

### Option 3: Use Virtual Host

1. **Enable virtual hosts** in httpd.conf:
   ```apache
   Include conf/extra/httpd-vhosts.conf
   ```

2. **Add to httpd-vhosts.conf** (use the provided apache_config.txt content)

3. **Add to hosts file** (C:/Windows/System32/drivers/etc/hosts):
   ```
   127.0.0.1 skillacademy.local
   ```

4. **Restart Apache**

5. **Access via browser**:
   ```
   http://skillacademy.local/
   ```

## Database Setup

1. **Open phpMyAdmin** (http://localhost/phpmyadmin/)
2. **Create database**: `skill_academy`
3. **Import**: `database.sql` file

## Testing

1. **Open**: `http://localhost/skill_academy/test_firebase_auth.html`
2. **Test Firebase initialization**
3. **Test registration and login**

## Common Issues & Solutions

### "Not Found" Error
- **Cause**: Wrong DocumentRoot or project not in web directory
- **Solution**: Use Option 1 (XAMPP) or check DocumentRoot path

### "Forbidden" Error
- **Cause**: Directory permissions
- **Solution**: Add `Require all granted` in Directory config

### PHP Not Working
- **Cause**: PHP module not loaded
- **Solution**: Ensure PHP module is enabled in Apache

### Python Script Not Working
- **Cause**: Python not in system PATH
- **Solution**: Add Python to system PATH or use full path in PHP

## File Permissions (Windows)
Right-click skill_academy folder → Properties → Security → Edit permissions:
- Give Full Control to:
  - Your user account
  - IIS_IUSRS (if using IIS)
  - Apache user (if using Apache)

## URL Structure
Once working, your URLs should be:
- Home: http://localhost/skill_academy/
- Login: http://localhost/skill_academy/login_firebase.php
- Register: http://localhost/skill_academy/register_firebase.php
- Dashboard: http://localhost/skill_academy/dashboard.php
- Test: http://localhost/skill_academy/test_firebase_auth.html
