<?php
// Database configuration for Skill Academy
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'skill_academy';

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8mb4
$conn->set_charset("utf8mb4");

// Function to sanitize input
function sanitize($conn, $input) {
    return htmlspecialchars($conn->real_escape_string($input));
}

// Function to check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Function to get user data
function getUserData($conn, $userId) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Function to check if user has premium membership
function hasPremium($conn, $userId) {
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM premium_memberships WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['count'] > 0;
}

// Function to check if user completed all basic courses
function completedAllBasics($conn, $userId) {
    $stmt = $conn->prepare("
        SELECT COUNT(*) as total, 
               SUM(CASE WHEN e.completed = 1 THEN 1 ELSE 0 END) as completed
        FROM courses c 
        LEFT JOIN enrollments e ON c.id = e.course_id AND e.user_id = ?
        WHERE c.level = 'basic'
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    return $row['total'] > 0 && $row['total'] == $row['completed'];
}

// Function to check if user can access advanced courses
function canAccessAdvanced($conn, $userId) {
    return completedAllBasics($conn, $userId) && hasPremium($conn, $userId);
}
?>
