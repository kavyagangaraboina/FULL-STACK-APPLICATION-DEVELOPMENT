<?php
// Manual Authentication Configuration
session_start();

// Security settings
define('HASH_ALGO', PASSWORD_DEFAULT);
define('HASH_OPTIONS', ['cost' => 12]);

// Session security
define('SESSION_LIFETIME', 3600); // 1 hour
define('REMEMBER_LIFETIME', 86400 * 30); // 30 days

// Initialize secure session
function initSecureSession() {
    // Prevent session hijacking
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_secure', isset($_SERVER['HTTPS']));
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Strict');
    
    // Set session lifetime
    ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
    
    session_start();
    
    // Regenerate session ID to prevent fixation
    if (!isset($_SESSION['regenerated'])) {
        session_regenerate_id(true);
        $_SESSION['regenerated'] = true;
    }
}

// Password hashing functions
function hashPassword($password) {
    return password_hash($password, HASH_ALGO, HASH_OPTIONS);
}

function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// User authentication functions
function loginUser($user) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_premium'] = $user['has_premium'] ?? false;
    $_SESSION['login_time'] = time();
    $_SESSION['ip_address'] = $_SERVER['REMOTE_ADDR'];
    $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
}

function logoutUser() {
    // Unset all session variables
    $_SESSION = array();
    
    // Delete session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    // Destroy session
    session_destroy();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']) && 
           isset($_SESSION['login_time']) && 
           isset($_SESSION['ip_address']) &&
           isset($_SESSION['user_agent']) &&
           $_SESSION['ip_address'] === $_SERVER['REMOTE_ADDR'] &&
           $_SESSION['user_agent'] === $_SERVER['HTTP_USER_AGENT'] &&
           (time() - $_SESSION['login_time']) < SESSION_LIFETIME;
}

function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // Update premium status
        $premiumStmt = $conn->prepare("SELECT COUNT(*) as count FROM premium_memberships WHERE user_id = ?");
        $premiumStmt->bind_param("i", $user['id']);
        $premiumStmt->execute();
        $premiumResult = $premiumStmt->get_result();
        $premiumRow = $premiumResult->fetch_assoc();
        $user['has_premium'] = $premiumRow['count'] > 0;
        
        // Update session
        $_SESSION['user_premium'] = $user['has_premium'];
        
        return $user;
    }
    
    return null;
}

// Redirect if not logged in
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

// Generate CSRF token
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Verify CSRF token
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Input validation
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validatePassword($password) {
    // Minimum 8 characters, at least 1 letter, 1 number
    return strlen($password) >= 8 && 
           preg_match('/[A-Za-z]/', $password) && 
           preg_match('/[0-9]/', $password);
}

// Rate limiting
function checkRateLimit($identifier, $maxAttempts = 5, $timeWindow = 300) {
    $cacheKey = "auth_attempts_{$identifier}";
    
    if (!isset($_SESSION[$cacheKey])) {
        $_SESSION[$cacheKey] = [];
    }
    
    $attempts = $_SESSION[$cacheKey];
    $now = time();
    
    // Remove old attempts
    $attempts = array_filter($attempts, function($timestamp) use ($now, $timeWindow) {
        return ($now - $timestamp) < $timeWindow;
    });
    
    if (count($attempts) >= $maxAttempts) {
        return false;
    }
    
    // Add current attempt
    $attempts[] = $now;
    $_SESSION[$cacheKey] = $attempts;
    
    return true;
}

// Initialize secure session
initSecureSession();
?>
