<?php
session_start();
require_once 'config/db.php';

header('Content-Type: application/json');

// Check if user is logged in
$userSession = isset($_SESSION['userSession']) ? $_SESSION['userSession'] : null;

if (!$userSession) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

$currentUser = json_decode($userSession, true);

// Get posted data
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['course_id'])) {
    echo json_encode(['success' => false, 'message' => 'Course ID is required']);
    exit;
}

$courseId = intval($data['course_id']);

// Check if user is enrolled in the course
$stmt = $conn->prepare("SELECT * FROM enrollments WHERE user_id = ? AND course_id = ?");
$stmt->bind_param("ii", $currentUser['id'], $courseId);
$stmt->execute();
$enrollmentResult = $stmt->get_result();

if ($enrollmentResult->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'You are not enrolled in this course']);
    exit;
}

// Mark course as completed
$stmt = $conn->prepare("UPDATE enrollments SET completed = 1 WHERE user_id = ? AND course_id = ?");
$stmt->bind_param("ii", $currentUser['id'], $courseId);

if ($stmt->execute()) {
    // Check if this completes all basic courses
    $stmt = $conn->prepare("
        SELECT COUNT(*) as total, 
               SUM(CASE WHEN e.completed = 1 THEN 1 ELSE 0 END) as completed
        FROM courses c 
        LEFT JOIN enrollments e ON c.id = e.course_id AND e.user_id = ?
        WHERE c.level = 'basic'
    ");
    $stmt->bind_param("i", $currentUser['id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    $message = 'Course marked as completed successfully!';
    
    // If all basic courses are completed, add special message
    if ($row['total'] > 0 && $row['total'] == $row['completed']) {
        $message .= ' Congratulations! You have completed all basic courses. You can now upgrade to premium to access advanced courses!';
    }
    
    echo json_encode(['success' => true, 'message' => $message]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to mark course as completed']);
}

$stmt->close();
$conn->close();
?>
