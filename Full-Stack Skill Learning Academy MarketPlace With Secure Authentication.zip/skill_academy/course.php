<?php
session_start();
require_once 'config/db.php';

// Check if user is logged in
$userSession = isset($_SESSION['userSession']) ? $_SESSION['userSession'] : null;

if (!$userSession) {
    header('Location: login_firebase.php');
    exit;
}

$currentUser = json_decode($userSession, true);

// Get course ID from URL
if (!isset($_GET['course_id'])) {
    header('Location: index.php');
    exit;
}

$courseId = intval($_GET['course_id']);

// Get course details
$stmt = $conn->prepare("SELECT * FROM courses WHERE id = ?");
$stmt->bind_param("i", $courseId);
$stmt->execute();
$courseResult = $stmt->get_result();

if ($courseResult->num_rows === 0) {
    header('Location: index.php');
    exit;
}

$course = $courseResult->fetch_assoc();

// Check if user is enrolled or if it's a basic course (allow preview)
$stmt = $conn->prepare("SELECT * FROM enrollments WHERE user_id = ? AND course_id = ?");
$stmt->bind_param("ii", $currentUser['id'], $courseId);
$stmt->execute();
$enrollmentResult = $stmt->get_result();
$isEnrolled = $enrollmentResult->num_rows > 0;

// Allow access to basic courses without enrollment, but require enrollment for advanced
if ($course['level'] === 'advanced' && !$isEnrolled) {
    $_SESSION['error_message'] = 'You need to enroll in this course to access the content.';
    header('Location: enroll.php?course_id=' . $courseId);
    exit;
}

// Course content data (in a real app, this would come from database)
$courseContents = [
    1 => [ // HTML Basics
        [
            'title' => 'Introduction to HTML',
            'description' => 'Learn the fundamentals of HTML and how web pages are structured.',
            'content' => '
                <h3>What is HTML?</h3>
                <p>HTML (HyperText Markup Language) is the standard markup language for creating web pages. It describes the structure and content of a webpage using elements and tags.</p>
                
                <h4>Key Concepts:</h4>
                <ul>
                    <li>HTML uses tags to define elements</li>
                    <li>Tags come in pairs: opening and closing</li>
                    <li>Elements can have attributes</li>
                    <li>HTML documents have a specific structure</li>
                </ul>
                
                <h4>Basic HTML Structure:</h4>
                <pre><code>&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;meta name="viewport" content="width=device-width, initial-scale=1.0"&gt;
    &lt;title&gt;My First Page&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;h1&gt;Hello, World!&lt;/h1&gt;
    &lt;p&gt;This is my first HTML page.&lt;/p&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
            ',
            'code_example' => '<!DOCTYPE html>\n<html>\n<head>\n    <title>My Page</title>\n</head>\n<body>\n    <h1>Welcome!</h1>\n</body>\n</html>',
            'exercise' => 'Create your first HTML page with a heading and a paragraph.',
            'next_lesson' => 2
        ],
        [
            'title' => 'HTML Elements and Tags',
            'description' => 'Deep dive into HTML elements, tags, and their attributes.',
            'content' => '
                <h3>HTML Elements</h3>
                <p>HTML elements are the building blocks of HTML pages. They are defined by tags, which are written using angle brackets.</p>
                
                <h4>Common HTML Elements:</h4>
                <div class="element-grid">
                    <div class="element-card">
                        <code>&lt;h1&gt; - &lt;h6&gt;</code>
                        <p>Headings from most important to least important</p>
                    </div>
                    <div class="element-card">
                        <code>&lt;p&gt;</code>
                        <p>Paragraphs of text</p>
                    </div>
                    <div class="element-card">
                        <code>&lt;a&gt;</code>
                        <p>Links to other pages or resources</p>
                    </div>
                    <div class="element-card">
                        <code>&lt;img&gt;</code>
                        <p>Images and graphics</p>
                    </div>
                    <div class="element-card">
                        <code>&lt;div&gt;</code>
                        <p>Container for other elements</p>
                    </div>
                    <div class="element-card">
                        <code>&lt;span&gt;</code>
                        <p>Inline container for text</p>
                    </div>
                </div>
                
                <h4>Attributes:</h4>
                <p>Attributes provide additional information about elements:</p>
                <pre><code>&lt;a href="https://example.com" target="_blank"&gt;Link&lt;/a&gt;
&lt;img src="image.jpg" alt="Description"&gt;
&lt;div class="container" id="main"&gt;Content&lt;/div&gt;</code></pre>
            ',
            'code_example' => '<h1>Main Title</h1>\n<p>Paragraph text with <a href="#">a link</a>.</p>\n<img src="photo.jpg" alt="Photo">',
            'exercise' => 'Create a page with headings, paragraphs, a link, and an image.',
            'next_lesson' => 3
        ],
        [
            'title' => 'Forms and User Input',
            'description' => 'Learn how to create interactive forms for user input.',
            'content' => '
                <h3>HTML Forms</h3>
                <p>Forms are used to collect user input. They contain different types of input elements like text fields, checkboxes, radio buttons, and submit buttons.</p>
                
                <h4>Form Elements:</h4>
                <pre><code>&lt;form action="/submit" method="POST"&gt;
    &lt;label for="name"&gt;Name:&lt;/label&gt;
    &lt;input type="text" id="name" name="name" required&gt;
    
    &lt;label for="email"&gt;Email:&lt;/label&gt;
    &lt;input type="email" id="email" name="email" required&gt;
    
    &lt;label for="message"&gt;Message:&lt;/label&gt;
    &lt;textarea id="message" name="message"&gt;&lt;/textarea&gt;
    
    &lt;input type="submit" value="Submit"&gt;
&lt;/form&gt;</code></pre>
                
                <h4>Input Types:</h4>
                <ul>
                    <li><code>text</code> - Single-line text input</li>
                    <li><code>email</code> - Email address input</li>
                    <li><code>password</code> - Password field</li>
                    <li><code>checkbox</code> - Checkbox for multiple selections</li>
                    <li><code>radio</code> - Radio button for single selection</li>
                    <li><code>submit</code> - Submit button</li>
                </ul>
            ',
            'code_example' => '<form>\n    <label>Name:</label>\n    <input type="text" name="name">\n    <input type="submit" value="Submit">\n</form>',
            'exercise' => 'Create a contact form with name, email, and message fields.',
            'next_lesson' => null
        ]
    ],
    2 => [ // CSS Fundamentals
        [
            'title' => 'Introduction to CSS',
            'description' => 'Learn how CSS styles HTML elements and creates beautiful web pages.',
            'content' => '
                <h3>What is CSS?</h3>
                <p>CSS (Cascading Style Sheets) is used to style and layout web pages. It controls colors, fonts, spacing, and positioning of HTML elements.</p>
                
                <h4>How CSS Works:</h4>
                <ul>
                    <li>CSS rules consist of selectors and declarations</li>
                    <li>Selectors target HTML elements</li>
                    <li>Declarations define how to style those elements</li>
                    <li>CSS can be applied inline, internally, or externally</li>
                </ul>
                
                <h4>CSS Syntax:</h4>
                <pre><code>selector {
    property: value;
    property: value;
}</code></pre>
                
                <h4>Example:</h4>
                <pre><code>h1 {
    color: blue;
    font-size: 24px;
    text-align: center;
}

p {
    color: #333;
    line-height: 1.6;
}</code></pre>
            ',
            'code_example' => 'h1 {\n    color: blue;\n    font-size: 24px;\n}\n\np {\n    color: #333;\n}',
            'exercise' => 'Style a simple HTML page with different colors and fonts.',
            'next_lesson' => 2
        ],
        [
            'title' => 'CSS Selectors and Properties',
            'description' => 'Master CSS selectors and understand common properties.',
            'content' => '
                <h3>CSS Selectors</h3>
                <p>Selectors are patterns used to select and style HTML elements.</p>
                
                <h4>Types of Selectors:</h4>
                <div class="selector-list">
                    <div class="selector-item">
                        <code>.class</code>
                        <p>Selects elements with a specific class</p>
                    </div>
                    <div class="selector-item">
                        <code>#id</code>
                        <p>Selects elements with a specific ID</p>
                    </div>
                    <div class="selector-item">
                        <code>element</code>
                        <p>Selects all elements of a type</p>
                    </div>
                    <div class="selector-item">
                        <code>element.class</code>
                        <p>Selects elements with specific type and class</p>
                    </div>
                </div>
                
                <h4>Common Properties:</h4>
                <pre><code>/* Text Properties */
color: #333;
font-size: 16px;
font-family: Arial, sans-serif;
text-align: center;

/* Box Properties */
width: 100px;
height: 100px;
padding: 10px;
margin: 20px;
border: 1px solid #ccc;

/* Background Properties */
background-color: #f0f0f0;
background-image: url("image.jpg");</code></pre>
            ',
            'code_example' => '.container {\n    width: 80%;\n    margin: 0 auto;\n    padding: 20px;\n    background: #f5f5f5;\n}',
            'exercise' => 'Create a layout using different selectors and properties.',
            'next_lesson' => 3
        ],
        [
            'title' => 'Layout and Positioning',
            'description' => 'Learn how to create layouts using CSS positioning and flexbox.',
            'content' => '
                <h3>CSS Layout</h3>
                <p>CSS provides several ways to create layouts: float, flexbox, and grid.</p>
                
                <h4>Flexbox Layout:</h4>
                <pre><code>.container {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.item {
    flex: 1;
    margin: 10px;
}</code></pre>
                
                <h4>Position Property:</h4>
                <ul>
                    <li><code>static</code> - Default positioning</li>
                    <li><code>relative</code> - Positioned relative to its normal position</li>
                    <li><code>absolute</code> - Positioned relative to the nearest positioned ancestor</li>
                    <li><code>fixed</code> - Positioned relative to the viewport</li>
                </ul>
                
                <h4>Example Layout:</h4>
                <pre><code>.header {
    position: fixed;
    top: 0;
    width: 100%;
    background: white;
    z-index: 1000;
}

.main-content {
    margin-top: 60px;
    display: flex;
    gap: 20px;
}</code></pre>
            ',
            'code_example' => '.flex-container {\n    display: flex;\n    justify-content: space-around;\n    align-items: center;\n}',
            'exercise' => 'Create a responsive layout using flexbox.',
            'next_lesson' => null
        ]
    ],
    3 => [ // JavaScript Basics
        [
            'title' => 'Introduction to JavaScript',
            'description' => 'Learn the fundamentals of JavaScript programming.',
            'content' => '
                <h3>What is JavaScript?</h3>
                <p>JavaScript is a programming language that enables interactive web pages. It can update content, control multimedia, animate images, and much more.</p>
                
                <h4>Key Features:</h4>
                <ul>
                    <li>Dynamic typing</li>
                    <li>Object-oriented programming</li>
                    <li>Event-driven programming</li>
                    <li>Runs in web browsers</li>
                </ul>
                
                <h4>Basic Syntax:</h4>
                <pre><code>// Variables
let name = "John";
const age = 25;
var isStudent = true;

// Functions
function greet(name) {
    return "Hello, " + name + "!";
}

// Calling functions
console.log(greet(name));</code></pre>
                
                <h4>Data Types:</h4>
                <ul>
                    <li>String: text values</li>
                    <li>Number: numeric values</li>
                    <li>Boolean: true/false</li>
                    <li>Array: ordered list of values</li>
                    <li>Object: key-value pairs</li>
                </ul>
            ',
            'code_example' => 'let message = "Hello World";\nconsole.log(message);\n\nfunction add(a, b) {\n    return a + b;\n}',
            'exercise' => 'Write a simple JavaScript program that greets the user.',
            'next_lesson' => 2
        ],
        [
            'title' => 'DOM Manipulation',
            'description' => 'Learn how to interact with HTML elements using JavaScript.',
            'content' => '
                <h3>Document Object Model (DOM)</h3>
                <p>The DOM is a programming interface for HTML documents. It represents the page structure as a tree of objects that can be manipulated with JavaScript.</p>
                
                <h4>Selecting Elements:</h4>
                <pre><code>// By ID
const element = document.getElementById("myId");

// By class name
const elements = document.getElementsByClassName("myClass");

// By CSS selector
const element = document.querySelector(".myClass");
const elements = document.querySelectorAll("div");</code></pre>
                
                <h4>Modifying Elements:</h4>
                <pre><code>// Change content
element.textContent = "New text";
element.innerHTML = "<strong>Bold text</strong>";

// Change styles
element.style.color = "red";
element.style.fontSize = "20px";

// Add/remove classes
element.classList.add("active");
element.classList.remove("inactive");
element.classList.toggle("visible");</code></pre>
                
                <h4>Event Handling:</h4>
                <pre><code>button.addEventListener("click", function() {
    alert("Button clicked!");
});

element.addEventListener("mouseover", function() {
    this.style.backgroundColor = "yellow";
});</code></pre>
            ',
            'code_example' => 'document.getElementById("myButton").addEventListener("click", function() {\n    alert("Hello!");\n});',
            'exercise' => 'Create an interactive page with buttons that change content.',
            'next_lesson' => 3
        ],
        [
            'title' => 'Working with Arrays and Objects',
            'description' => 'Master JavaScript arrays and objects for data manipulation.',
            'content' => '
                <h3>JavaScript Arrays</h3>
                <p>Arrays are ordered collections of values that can hold multiple data types.</p>
                
                <h4>Array Methods:</h4>
                <pre><code>// Creating arrays
const fruits = ["apple", "banana", "orange"];
const numbers = [1, 2, 3, 4, 5];

// Common methods
fruits.push("grape");        // Add to end
fruits.pop();                // Remove from end
fruits.unshift("pear");      // Add to beginning
fruits.shift();              // Remove from beginning

// Iterating
fruits.forEach(function(fruit) {
    console.log(fruit);
});

// Transforming
const upperFruits = fruits.map(fruit => fruit.toUpperCase());
const longFruits = fruits.filter(fruit => fruit.length > 5);</code></pre>
                
                <h3>JavaScript Objects</h3>
                <p>Objects are collections of key-value pairs.</p>
                
                <pre><code>// Creating objects
const person = {
    name: "John",
    age: 30,
    city: "New York",
    greet: function() {
        return "Hello, I\'m " + this.name;
    }
};

// Accessing properties
console.log(person.name);
console.log(person["age"]);

// Modifying objects
person.email = "john@example.com";
person.age = 31;

// Object methods
const keys = Object.keys(person);
const values = Object.values(person);</code></pre>
            ',
            'code_example' => 'const users = [\n    {name: "Alice", age: 25},\n    {name: "Bob", age: 30}\n];\n\nusers.forEach(user => {\n    console.log(user.name);\n});',
            'exercise' => 'Create a program that manages a list of students using arrays and objects.',
            'next_lesson' => null
        ]
    ]
];

// Get current lesson
$currentLesson = isset($_GET['lesson']) ? intval($_GET['lesson']) : 1;
$courseContent = isset($courseContents[$courseId]) ? $courseContents[$courseId] : [];

// Validate lesson exists
if (!isset($courseContent[$currentLesson - 1])) {
    $currentLesson = 1;
}

$lesson = $courseContent[$currentLesson - 1];
$totalLessons = count($courseContent);
$progress = ($currentLesson / $totalLessons) * 100;

// Mark progress if enrolled
if ($isEnrolled) {
    // In a real app, you would save progress to database
    $_SESSION['course_progress'][$courseId] = $currentLesson;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($course['title']); ?> - Skill Academy</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .course-viewer {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 2rem 0;
        }

        .course-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
        }

        .course-header {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .course-title {
            font-size: 2.5rem;
            color: var(--primary-color);
            margin-bottom: 1rem;
        }

        .progress-bar {
            background: #e9ecef;
            height: 8px;
            border-radius: 4px;
            overflow: hidden;
            margin: 1rem 0;
        }

        .progress-fill {
            background: var(--success-color);
            height: 100%;
            transition: width 0.3s ease;
        }

        .lesson-navigation {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 1rem;
        }

        .lesson-content {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .lesson-title {
            font-size: 2rem;
            color: var(--text-primary);
            margin-bottom: 1rem;
        }

        .lesson-description {
            color: var(--text-secondary);
            font-size: 1.1rem;
            margin-bottom: 2rem;
        }

        .content-section h3 {
            color: var(--primary-color);
            margin: 2rem 0 1rem 0;
        }

        .content-section h4 {
            color: var(--text-primary);
            margin: 1.5rem 0 0.5rem 0;
        }

        .content-section pre {
            background: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 1rem;
            overflow-x: auto;
            margin: 1rem 0;
        }

        .content-section code {
            background: #f8f9fa;
            padding: 0.2rem 0.4rem;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
        }

        .element-grid, .selector-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
            margin: 1rem 0;
        }

        .element-card, .selector-item {
            background: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 1rem;
        }

        .element-card code, .selector-item code {
            display: block;
            background: var(--primary-color);
            color: white;
            padding: 0.5rem;
            border-radius: 4px;
            margin-bottom: 0.5rem;
        }

        .code-playground {
            background: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 1rem;
            margin: 2rem 0;
        }

        .code-editor {
            width: 100%;
            min-height: 150px;
            font-family: 'Courier New', monospace;
            padding: 1rem;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            resize: vertical;
        }

        .exercise-section {
            background: #e3f2fd;
            border: 1px solid #bbdefb;
            border-radius: 8px;
            padding: 1.5rem;
            margin: 2rem 0;
        }

        .lesson-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 2rem;
            padding-top: 2rem;
            border-top: 1px solid #e9ecef;
        }

        .btn-lesson {
            background: var(--primary-color);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: background 0.3s;
        }

        .btn-lesson:hover {
            background: var(--primary-dark);
        }

        .btn-lesson:disabled {
            background: var(--text-light);
            cursor: not-allowed;
        }

        @media (max-width: 768px) {
            .course-title {
                font-size: 1.8rem;
            }
            
            .lesson-navigation {
                flex-direction: column;
                gap: 1rem;
            }
            
            .lesson-actions {
                flex-direction: column;
                gap: 1rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-brand">
                <h1>Skill Academy</h1>
            </div>
            <div class="nav-menu">
                <span class="nav-user">Welcome, <?php echo htmlspecialchars($currentUser['name']); ?></span>
                <a href="dashboard.php" class="nav-link">Dashboard</a>
                <a href="index.php" class="nav-link">Home</a>
                <button id="logoutBtn" class="btn btn-outline">Logout</button>
            </div>
        </div>
    </nav>

    <!-- Course Viewer -->
    <section class="course-viewer">
        <div class="course-container">
            <!-- Course Header -->
            <div class="course-header">
                <h1 class="course-title"><?php echo htmlspecialchars($course['title']); ?></h1>
                <p class="course-description"><?php echo htmlspecialchars($course['description']); ?></p>
                
                <!-- Progress Bar -->
                <div class="progress-info">
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: <?php echo $progress; ?>%"></div>
                    </div>
                    <p>Lesson <?php echo $currentLesson; ?> of <?php echo $totalLessons; ?> (<?php echo round($progress); ?>% complete)</p>
                </div>

                <!-- Lesson Navigation -->
                <div class="lesson-navigation">
                    <div class="lesson-info">
                        <span class="lesson-number">Lesson <?php echo $currentLesson; ?></span>
                        <h3><?php echo htmlspecialchars($lesson['title']); ?></h3>
                    </div>
                    <div class="lesson-nav-buttons">
                        <?php if ($currentLesson > 1): ?>
                            <a href="?course_id=<?php echo $courseId; ?>&lesson=<?php echo $currentLesson - 1; ?>" class="btn btn-outline btn-small">
                                ← Previous
                            </a>
                        <?php endif; ?>
                        
                        <?php if ($currentLesson < $totalLessons): ?>
                            <a href="?course_id=<?php echo $courseId; ?>&lesson=<?php echo $currentLesson + 1; ?>" class="btn btn-primary btn-small">
                                Next →
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Lesson Content -->
            <div class="lesson-content">
                <h2 class="lesson-title"><?php echo htmlspecialchars($lesson['title']); ?></h2>
                <p class="lesson-description"><?php echo htmlspecialchars($lesson['description']); ?></p>

                <div class="content-section">
                    <?php echo $lesson['content']; ?>
                </div>

                <!-- Code Playground -->
                <div class="code-playground">
                    <h3>Try It Yourself</h3>
                    <p>Edit the code below and see how it works:</p>
                    <textarea class="code-editor" id="codeEditor"><?php echo htmlspecialchars($lesson['code_example']); ?></textarea>
                    <div style="margin-top: 1rem;">
                        <button onclick="runCode()" class="btn btn-primary">Run Code</button>
                        <button onclick="resetCode()" class="btn btn-outline">Reset</button>
                    </div>
                    <div id="codeOutput" style="margin-top: 1rem; padding: 1rem; background: #f8f9fa; border-radius: 4px; display: none;">
                        <h4>Output:</h4>
                        <div id="outputContent"></div>
                    </div>
                </div>

                <!-- Exercise Section -->
                <div class="exercise-section">
                    <h3>📝 Exercise</h3>
                    <p><?php echo htmlspecialchars($lesson['exercise']); ?></p>
                    <div style="margin-top: 1rem;">
                        <button onclick="markExerciseComplete()" class="btn btn-success">
                            Mark Exercise as Complete
                        </button>
                    </div>
                </div>

                <!-- Lesson Actions -->
                <div class="lesson-actions">
                    <div>
                        <?php if ($currentLesson > 1): ?>
                            <a href="?course_id=<?php echo $courseId; ?>&lesson=<?php echo $currentLesson - 1; ?>" class="btn btn-outline">
                                ← Previous Lesson
                            </a>
                        <?php endif; ?>
                    </div>
                    
                    <div>
                        <?php if ($currentLesson < $totalLessons): ?>
                            <a href="?course_id=<?php echo $courseId; ?>&lesson=<?php echo $currentLesson + 1; ?>" class="btn btn-primary">
                                Next Lesson →
                            </a>
                        <?php else: ?>
                            <?php if ($isEnrolled): ?>
                                <a href="mark_complete.php?course_id=<?php echo $courseId; ?>" class="btn btn-success">
                                    Mark Course as Complete
                                </a>
                            <?php endif; ?>
                            <a href="dashboard.php" class="btn btn-outline">
                                Back to Dashboard
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="firebase_config.js"></script>
    <script>
        const originalCode = <?php echo json_encode($lesson['code_example']); ?>;
        
        function runCode() {
            const code = document.getElementById('codeEditor').value;
            const outputDiv = document.getElementById('codeOutput');
            const outputContent = document.getElementById('outputContent');
            
            try {
                // For HTML/CSS courses, show preview
                if (code.includes('<') && code.includes('>')) {
                    outputContent.innerHTML = code;
                } else {
                    // For JavaScript, try to execute
                    const result = eval(code);
                    outputContent.textContent = result !== undefined ? result : 'Code executed successfully';
                }
                outputDiv.style.display = 'block';
            } catch (error) {
                outputContent.textContent = 'Error: ' + error.message;
                outputDiv.style.display = 'block';
            }
        }
        
        function resetCode() {
            document.getElementById('codeEditor').value = originalCode;
            document.getElementById('codeOutput').style.display = 'none';
        }
        
        function markExerciseComplete() {
            alert('Exercise marked as complete! Great work!');
            // In a real app, this would save to the database
        }
        
        // Auto-save code to localStorage
        const codeEditor = document.getElementById('codeEditor');
        codeEditor.addEventListener('input', function() {
            localStorage.setItem('courseCode_<?php echo $courseId; ?>_<?php echo $currentLesson; ?>', this.value);
        });
        
        // Load saved code if exists
        const savedCode = localStorage.getItem('courseCode_<?php echo $courseId; ?>_<?php echo $currentLesson; ?>');
        if (savedCode) {
            codeEditor.value = savedCode;
        }
    </script>
</body>
</html>
