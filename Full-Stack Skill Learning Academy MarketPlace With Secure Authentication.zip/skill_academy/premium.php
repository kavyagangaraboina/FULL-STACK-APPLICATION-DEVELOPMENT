<?php
session_start();
require_once 'config/db.php';

// Check if user is logged in
$userSession = isset($_SESSION['userSession']) ? $_SESSION['userSession'] : null;

if (!$userSession) {
    header('Location: login_firebase.php');
    exit;
}

$currentUser = json_decode($userSession, true);

// Check if user already has premium
$hasPremium = hasPremium($conn, $currentUser['id']);
$completedAllBasics = completedAllBasics($conn, $currentUser['id']);

// Handle premium activation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['activate_premium'])) {
    if (!$hasPremium) {
        $stmt = $conn->prepare("INSERT INTO premium_memberships (user_id) VALUES (?)");
        $stmt->bind_param("i", $currentUser['id']);
        
        if ($stmt->execute()) {
            $hasPremium = true;
            $successMessage = "Premium membership activated successfully!";
        } else {
            $errorMessage = "Failed to activate premium membership. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Premium Membership - Skill Academy</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Firebase SDK -->
    <script src="https://www.gstatic.com/firebasejs/9.6.1/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.6.1/firebase-auth-compat.js"></script>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-brand">
                <h1>Skill Academy</h1>
            </div>
            <div class="nav-menu">
                <span class="nav-user">Welcome, <?php echo htmlspecialchars($currentUser['name']); ?></span>
                <?php if ($hasPremium): ?>
                    <span class="premium-badge">PREMIUM</span>
                <?php endif; ?>
                <a href="dashboard.php" class="nav-link">Dashboard</a>
                <a href="index.php" class="nav-link">Home</a>
                <button id="logoutBtn" class="btn btn-outline">Logout</button>
            </div>
        </div>
    </nav>

    <!-- Premium Hero Section -->
    <section class="premium-hero">
        <div class="container">
            <div class="premium-content">
                <?php if ($hasPremium): ?>
                    <div class="premium-active">
                        <div class="premium-icon">👑</div>
                        <h1>You're a Premium Member!</h1>
                        <p>Thank you for being a valued member of Skill Academy. You now have access to all advanced courses and premium features.</p>
                        <div class="premium-benefits">
                            <div class="benefit-item">
                                <span class="benefit-icon">✓</span>
                                <span>Access to all advanced courses</span>
                            </div>
                            <div class="benefit-item">
                                <span class="benefit-icon">✓</span>
                                <span>Premium support and resources</span>
                            </div>
                            <div class="benefit-item">
                                <span class="benefit-icon">✓</span>
                                <span>Certificate of completion</span>
                            </div>
                        </div>
                        <a href="dashboard.php" class="btn btn-primary btn-large">Go to Dashboard</a>
                    </div>
                <?php else: ?>
                    <div class="premium-pitch">
                        <div class="premium-icon">⭐</div>
                        <h1>Upgrade to Premium</h1>
                        <p>Unlock advanced courses and take your skills to the next level with Skill Academy Premium.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php if (!$hasPremium): ?>
        <!-- Requirements Check -->
        <section class="requirements-section">
            <div class="container">
                <div class="requirements-card">
                    <h2>Before Upgrading to Premium</h2>
                    <p>Please ensure you meet the following requirements:</p>
                    <div class="requirements-list">
                        <div class="requirement-item <?php echo $completedAllBasics ? 'met' : 'unmet'; ?>">
                            <span class="requirement-icon"><?php echo $completedAllBasics ? '✓' : '○'; ?></span>
                            <div class="requirement-content">
                                <h4>Complete All Basic Courses</h4>
                                <p>You must finish all basic courses before accessing advanced content.</p>
                            </div>
                        </div>
                    </div>
                    <?php if (!$completedAllBasics): ?>
                        <div class="requirement-action">
                            <p>Complete your basic courses first:</p>
                            <a href="dashboard.php" class="btn btn-outline">Go to Dashboard</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <?php if ($completedAllBasics): ?>
            <!-- Pricing Section -->
            <section class="pricing-section">
                <div class="container">
                    <div class="section-header">
                        <h2>Choose Your Plan</h2>
                        <p>Select the perfect plan for your learning journey</p>
                    </div>

                    <div class="pricing-grid">
                        <!-- Free Plan -->
                        <div class="pricing-card">
                            <div class="pricing-header">
                                <h3>Free</h3>
                                <div class="pricing-price">
                                    <span class="price">$0</span>
                                    <span class="period">/month</span>
                                </div>
                            </div>
                            <div class="pricing-features">
                                <ul>
                                    <li>✓ All basic courses</li>
                                    <li>✓ Progress tracking</li>
                                    <li>✓ Certificate of completion</li>
                                    <li>✗ Advanced courses</li>
                                    <li>✗ Premium support</li>
                                </ul>
                            </div>
                            <div class="pricing-action">
                                <button class="btn btn-outline" disabled>Current Plan</button>
                            </div>
                        </div>

                        <!-- Premium Plan -->
                        <div class="pricing-card featured">
                            <div class="pricing-badge">RECOMMENDED</div>
                            <div class="pricing-header">
                                <h3>Premium</h3>
                                <div class="pricing-price">
                                    <span class="price">$29</span>
                                    <span class="period">/month</span>
                                </div>
                            </div>
                            <div class="pricing-features">
                                <ul>
                                    <li>✓ Everything in Free</li>
                                    <li>✓ All advanced courses</li>
                                    <li>✓ Premium support</li>
                                    <li>✓ Downloadable resources</li>
                                    <li>✓ Priority course updates</li>
                                </ul>
                            </div>
                            <div class="pricing-action">
                                <form method="POST">
                                    <button type="submit" name="activate_premium" class="btn btn-primary btn-large">
                                        Activate Premium
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Benefits Section -->
            <section class="premium-benefits-section">
                <div class="container">
                    <div class="section-header">
                        <h2>Why Go Premium?</h2>
                        <p>Discover the benefits of premium membership</p>
                    </div>

                    <div class="benefits-grid">
                        <div class="benefit-card">
                            <div class="benefit-icon">🚀</div>
                            <h3>Advanced Learning</h3>
                            <p>Access cutting-edge courses in full-stack development, machine learning, and more.</p>
                        </div>
                        <div class="benefit-card">
                            <div class="benefit-icon">🎯</div>
                            <h3>Expert Support</h3>
                            <p>Get priority support from our team of experienced instructors and developers.</p>
                        </div>
                        <div class="benefit-card">
                            <div class="benefit-icon">📚</div>
                            <h3>Exclusive Resources</h3>
                            <p>Download course materials, source code, and additional learning resources.</p>
                        </div>
                        <div class="benefit-card">
                            <div class="benefit-icon">🏆</div>
                            <h3>Certificates</h3>
                            <p>Earn verified certificates for completed courses to showcase your skills.</p>
                        </div>
                    </div>
                </div>
            </section>
        <?php endif; ?>
    <?php endif; ?>

    <!-- Success/Error Messages -->
    <?php if (isset($successMessage)): ?>
        <div class="message success">
            <?php echo htmlspecialchars($successMessage); ?>
        </div>
    <?php endif; ?>

    <?php if (isset($errorMessage)): ?>
        <div class="message error">
            <?php echo htmlspecialchars($errorMessage); ?>
        </div>
    <?php endif; ?>

    <!-- FAQ Section -->
    <section class="faq-section">
        <div class="container">
            <div class="section-header">
                <h2>Frequently Asked Questions</h2>
            </div>

            <div class="faq-list">
                <div class="faq-item">
                    <div class="faq-question">
                        <h4>What's included in Premium membership?</h4>
                        <span class="faq-toggle">+</span>
                    </div>
                    <div class="faq-answer">
                        <p>Premium membership includes access to all advanced courses, priority support, downloadable resources, and verified certificates of completion.</p>
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question">
                        <h4>Can I cancel my Premium membership?</h4>
                        <span class="faq-toggle">+</span>
                    </div>
                    <div class="faq-answer">
                        <p>Yes, you can cancel your Premium membership at any time. You'll continue to have access until the end of your billing period.</p>
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question">
                        <h4>Do I need to complete basic courses first?</h4>
                        <span class="faq-toggle">+</span>
                    </div>
                    <div class="faq-answer">
                        <p>Yes, our learning path is structured to ensure you have the foundational knowledge before advancing to more complex topics.</p>
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question">
                        <h4>Is payment processing secure?</h4>
                        <span class="faq-toggle">+</span>
                    </div>
                    <div class="faq-answer">
                        <p>Yes, we use industry-standard encryption and secure payment processors to protect your financial information.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        // FAQ Toggle functionality
        document.addEventListener('DOMContentLoaded', function() {
            const faqItems = document.querySelectorAll('.faq-item');
            
            faqItems.forEach(item => {
                const question = item.querySelector('.faq-question');
                const answer = item.querySelector('.faq-answer');
                const toggle = item.querySelector('.faq-toggle');
                
                question.addEventListener('click', function() {
                    answer.classList.toggle('active');
                    toggle.textContent = answer.classList.contains('active') ? '-' : '+';
                });
            });
        });
    </script>

    <script src="firebase_config.js"></script>
</body>
</html>
