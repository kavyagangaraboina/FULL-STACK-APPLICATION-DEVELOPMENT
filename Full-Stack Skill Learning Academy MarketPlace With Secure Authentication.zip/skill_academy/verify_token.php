<?php
// Firebase Admin SDK Token Verification (using Python)
require_once 'config/db.php';

header('Content-Type: application/json');

// Get the posted data
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['idToken'])) {
    echo json_encode(['success' => false, 'message' => 'ID token is required']);
    exit;
}

$idToken = $data['idToken'];

// Verify Firebase ID token using Python Admin SDK
function verifyFirebaseTokenWithPython($idToken) {
    // Call the Python verification script
    $command = escapeshellcmd("python3 verify_token_admin.py " . escapeshellarg($idToken));
    $output = shell_exec($command);
    
    if ($output === null) {
        return null;
    }
    
    $result = json_decode($output, true);
    
    if ($result && isset($result['success']) && $result['success']) {
        return $result['user'];
    }
    
    return null;
}

// Verify the token
$userData = verifyFirebaseTokenWithPython($idToken);

if ($userData === null) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

// Get user from database or create new user
$firebaseUid = $userData['uid'];
$email = $userData['email'];
$name = isset($userData['name']) ? $userData['name'] : $userData['email'];

$stmt = $conn->prepare("SELECT * FROM users WHERE firebase_uid = ?");
$stmt->bind_param("s", $firebaseUid);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // Create new user
    $stmt = $conn->prepare("INSERT INTO users (firebase_uid, name, email) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $firebaseUid, $name, $email);
    
    if ($stmt->execute()) {
        $userId = $conn->insert_id;
        $user = [
            'id' => $userId,
            'firebase_uid' => $firebaseUid,
            'name' => $name,
            'email' => $email
        ];
        echo json_encode(['success' => true, 'user' => $user, 'message' => 'User created successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to create user']);
    }
} else {
    // User exists, return user data
    $user = $result->fetch_assoc();
    echo json_encode(['success' => true, 'user' => $user, 'message' => 'User verified successfully']);
}

$stmt->close();
$conn->close();
?>
