<?php
session_start();
require_once 'config/db.php';

// Check if user is logged in
$userSession = isset($_SESSION['userSession']) ? $_SESSION['userSession'] : null;

if (!$userSession) {
    header('Location: login_firebase.php');
    exit;
}

$currentUser = json_decode($userSession, true);

// Get course ID from URL
if (!isset($_GET['course_id'])) {
    header('Location: index.php');
    exit;
}

$courseId = intval($_GET['course_id']);

// Get course details
$stmt = $conn->prepare("SELECT * FROM courses WHERE id = ?");
$stmt->bind_param("i", $courseId);
$stmt->execute();
$courseResult = $stmt->get_result();

if ($courseResult->num_rows === 0) {
    header('Location: index.php');
    exit;
}

$course = $courseResult->fetch_assoc();

// Check if already enrolled
$stmt = $conn->prepare("SELECT * FROM enrollments WHERE user_id = ? AND course_id = ?");
$stmt->bind_param("ii", $currentUser['id'], $courseId);
$stmt->execute();
$enrollmentResult = $stmt->get_result();

if ($enrollmentResult->num_rows > 0) {
    // Already enrolled, redirect to dashboard
    header('Location: dashboard.php');
    exit;
}

// Check access permissions for advanced courses
if ($course['level'] === 'advanced') {
    $hasPremium = hasPremium($conn, $currentUser['id']);
    $completedAllBasics = completedAllBasics($conn, $currentUser['id']);
    
    if (!$hasPremium || !$completedAllBasics) {
        // Cannot access advanced course
        $_SESSION['error_message'] = 'You need to complete all basic courses and have premium membership to access this course.';
        header('Location: premium.php');
        exit;
    }
}

// Handle enrollment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['enroll'])) {
    $stmt = $conn->prepare("INSERT INTO enrollments (user_id, course_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $currentUser['id'], $courseId);
    
    if ($stmt->execute()) {
        $_SESSION['success_message'] = 'Successfully enrolled in ' . htmlspecialchars($course['title']) . '!';
        header('Location: course.php?course_id=' . $courseId);
        exit;
    } else {
        $error = 'Failed to enroll in course. Please try again.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enroll in Course - Skill Academy</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Firebase SDK -->
    <script src="https://www.gstatic.com/firebasejs/9.6.1/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.6.1/firebase-auth-compat.js"></script>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-brand">
                <h1>Skill Academy</h1>
            </div>
            <div class="nav-menu">
                <span class="nav-user">Welcome, <?php echo htmlspecialchars($currentUser['name']); ?></span>
                <a href="dashboard.php" class="nav-link">Dashboard</a>
                <a href="index.php" class="nav-link">Home</a>
                <button id="logoutBtn" class="btn btn-outline">Logout</button>
            </div>
        </div>
    </nav>

    <!-- Enrollment Section -->
    <section class="enrollment-section">
        <div class="container">
            <div class="enrollment-card">
                <div class="course-preview">
                    <div class="course-image">
                        <img src="assets/images/<?php echo htmlspecialchars($course['image']); ?>" alt="<?php echo htmlspecialchars($course['title']); ?>">
                    </div>
                    
                    <div class="course-info">
                        <h2><?php echo htmlspecialchars($course['title']); ?></h2>
                        <p class="course-description"><?php echo htmlspecialchars($course['description']); ?></p>
                        
                        <div class="course-meta">
                            <span class="course-level <?php echo $course['level']; ?>">
                                <?php echo ucfirst($course['level']); ?> Course
                            </span>
                        </div>
                    </div>
                </div>

                <div class="enrollment-content">
                    <h3>Ready to Start Learning?</h3>
                    
                    <?php if ($course['level'] === 'advanced'): ?>
                        <div class="access-confirmation">
                            <h4>✅ Advanced Course Access Confirmed</h4>
                            <p>You have met all requirements to access this advanced course:</p>
                            <ul>
                                <li>✓ Completed all basic courses</li>
                                <li>✓ Active premium membership</li>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if (isset($error)): ?>
                        <div class="message error">
                            <?php echo htmlspecialchars($error); ?>
                        </div>
                    <?php endif; ?>

                    <div class="enrollment-benefits">
                        <h4>What you'll get:</h4>
                        <ul>
                            <li>📚 Full course content and materials</li>
                            <li>🎯 Structured learning path</li>
                            <li>📊 Progress tracking</li>
                            <li>🏆 Certificate upon completion</li>
                            <?php if ($course['level'] === 'advanced'): ?>
                                <li>⭐ Premium support and resources</li>
                            <?php endif; ?>
                        </ul>
                    </div>

                    <form method="POST" class="enrollment-form">
                        <div class="form-actions">
                            <button type="submit" name="enroll" class="btn btn-primary btn-large">
                                Start Learning Now
                            </button>
                            <a href="index.php" class="btn btn-outline">Cancel</a>
                        </div>
                    </form>

                    <div class="enrollment-note">
                        <p><strong>Note:</strong> By enrolling, you agree to our terms of service and learning commitment. You can access this course anytime from your dashboard.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="firebase_config.js"></script>
</body>
</html>
