<?php
require_once 'config/db.php';
require_once 'config/auth.php';

header('Content-Type: application/json');

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get and validate input
$name = sanitizeInput($_POST['name'] ?? '');
$email = sanitizeInput($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$confirmPassword = $_POST['confirm_password'] ?? '';

// CSRF protection
if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    echo json_encode(['success' => false, 'message' => 'Invalid request token']);
    exit;
}

// Rate limiting
if (!checkRateLimit($email)) {
    echo json_encode(['success' => false, 'message' => 'Too many registration attempts. Please try again later.']);
    exit;
}

// Validate input
if (empty($name) || empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit;
}

if (!validateEmail($email)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email address']);
    exit;
}

if (!validatePassword($password)) {
    echo json_encode(['success' => false, 'message' => 'Password must be at least 8 characters with at least 1 letter and 1 number']);
    exit;
}

if ($password !== $confirmPassword) {
    echo json_encode(['success' => false, 'message' => 'Passwords do not match']);
    exit;
}

if (strlen($name) < 2 || strlen($name) > 100) {
    echo json_encode(['success' => false, 'message' => 'Name must be between 2 and 100 characters']);
    exit;
}

try {
    // Check if user already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'Email address already exists']);
        exit;
    }
    
    // Hash password
    $passwordHash = hashPassword($password);
    
    // Generate verification token
    $verificationToken = bin2hex(random_bytes(32));
    
    // Insert new user
    $stmt = $conn->prepare("
        INSERT INTO users (name, email, password_hash, email_verified, verification_token) 
        VALUES (?, ?, ?, FALSE, ?)
    ");
    $stmt->bind_param("ssss", $name, $email, $passwordHash, $verificationToken);
    
    if ($stmt->execute()) {
        $userId = $conn->insert_id;
        
        // Log registration attempt
        $logStmt = $conn->prepare("
            INSERT INTO login_attempts (email, ip_address, user_agent, success) 
            VALUES (?, ?, ?, TRUE)
        ");
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
        $logStmt->bind_param("sss", $email, $ipAddress, $userAgent);
        $logStmt->execute();
        
        // Auto-login the user (skip email verification for demo)
        $user = [
            'id' => $userId,
            'name' => $name,
            'email' => $email,
            'has_premium' => false
        ];
        
        loginUser($user);
        
        echo json_encode([
            'success' => true, 
            'message' => 'Registration successful! Redirecting to dashboard...',
            'user' => $user
        ]);
        
    } else {
        echo json_encode(['success' => false, 'message' => 'Registration failed. Please try again.']);
    }
    
} catch (Exception $e) {
    error_log("Registration error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred. Please try again.']);
}

$stmt->close();
$conn->close();
?>
