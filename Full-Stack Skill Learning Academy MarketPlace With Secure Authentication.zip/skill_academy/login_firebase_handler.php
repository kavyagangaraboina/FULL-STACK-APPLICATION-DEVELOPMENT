<?php
session_start();
require_once 'config/db.php';

header('Content-Type: application/json');

// Get the posted data
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['idToken'])) {
    echo json_encode(['success' => false, 'message' => 'ID token is required']);
    exit;
}

$idToken = $data['idToken'];

// Verify Firebase ID token using Python Admin SDK
function verifyFirebaseTokenWithPython($idToken) {
    // Try different Python commands
    $pythonCommands = ['python', 'python3'];
    $output = null;
    
    foreach ($pythonCommands as $pythonCmd) {
        $command = escapeshellcmd("$pythonCmd verify_token_admin.py " . escapeshellarg($idToken));
        $output = shell_exec($command);
        
        if ($output !== null && !empty($output)) {
            break;
        }
    }
    
    if ($output === null) {
        return null;
    }
    
    $result = json_decode($output, true);
    
    if ($result && isset($result['success']) && $result['success']) {
        return $result['user'];
    }
    
    return null;
}

// Verify the token
$tokenData = verifyFirebaseTokenWithPython($idToken);

if ($tokenData === null) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

// Get user from database
$stmt = $conn->prepare("SELECT * FROM users WHERE firebase_uid = ?");
$stmt->bind_param("s", $tokenData['uid']);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'User not found. Please register first.']);
    exit;
}

$user = $result->fetch_assoc();

// Check if user has premium membership
$premiumStmt = $conn->prepare("SELECT COUNT(*) as count FROM premium_memberships WHERE user_id = ?");
$premiumStmt->bind_param("i", $user['id']);
$premiumStmt->execute();
$premiumResult = $premiumStmt->get_result();
$premiumRow = $premiumResult->fetch_assoc();
$user['has_premium'] = $premiumRow['count'] > 0;

// Store in PHP session as backup
$_SESSION['userSession'] = json_encode($user);

echo json_encode(['success' => true, 'user' => $user, 'message' => 'Login successful']);

$stmt->close();
$premiumStmt->close();
$conn->close();
?>
