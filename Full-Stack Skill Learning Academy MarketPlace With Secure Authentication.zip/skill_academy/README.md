# Skill Academy - Full-Stack Learning Marketplace

A comprehensive skill learning platform with Firebase Authentication and order-based course progression system.

## 🚀 Features

- **Firebase Authentication**: Secure email/password authentication
- **Order-Based Learning**: Complete basic courses before accessing advanced content
- **Premium Membership**: Unlock advanced courses with premium subscription
- **Progress Tracking**: Monitor your learning journey
- **Responsive Design**: Modern, mobile-friendly interface
- **Course Management**: Enroll, track, and complete courses
- **Security**: Token verification and protected routes

## 🛠️ Tech Stack

- **Frontend**: HTML5, CSS3, ES6 (Vanilla JavaScript)
- **Backend**: PHP
- **Authentication**: Firebase Authentication
- **Database**: MySQL
- **Server**: XAMPP (localhost)

## 📋 Prerequisites

1. **XAMPP** installed and running
2. **MySQL** database access
3. **Firebase Project** with Email/Password authentication enabled
4. **Web Browser** with JavaScript enabled

## 🗂️ Project Structure

```
skill_academy/
├── config/
│   ├── db.php                    # Database configuration
│   └── firebase_credentials.json # Firebase service account credentials
├── assets/
│   ├── css/
│   │   └── style.css            # Complete CSS styling
│   ├── js/
│   │   └── script.js            # JavaScript functionality
│   └── images/                  # Course images (add your own)
├── index.php                    # Homepage with course listing
├── register_firebase.php        # User registration page
├── login_firebase.php          # User login page
├── logout.php                  # Logout handler
├── dashboard.php               # User dashboard with progress
├── premium.php                 # Premium membership page
├── enroll.php                  # Course enrollment page
├── verify_token.php            # Firebase token verification
├── register_firebase_handler.php # Registration backend
├── login_firebase_handler.php   # Login backend
├── mark_complete.php           # Course completion handler
├── firebase_config.js          # Firebase configuration
├── database.sql                # Database schema and sample data
└── README.md                   # This file
```

## 🛠️ Setup Instructions

### 1. Database Setup

1. Start XAMPP and ensure Apache and MySQL are running
2. Open phpMyAdmin (http://localhost/phpmyadmin)
3. Create a new database named `skill_academy`
4. Import the `database.sql` file to create tables and sample data

### 2. Firebase Setup

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create a new project or use an existing one
3. Enable **Email/Password** authentication in Authentication → Sign-in method
4. Go to Project Settings → Service accounts
5. Generate a new private key and save it as `config/firebase_credentials.json`
6. Get your Firebase configuration from Project Settings → General → Your apps
7. Update `firebase_config.js` with your Firebase project configuration:

```javascript
const firebaseConfig = {
    apiKey: "AIzaSyA70mBz8uH5fQ1Agvc_3jBDxpL3g1v_7yU",
    authDomain: "skill-academy1.firebaseapp.com",
    projectId: "skill-academy1",
    storageBucket: "skill-academy1.firebasestorage.app",
    messagingSenderId: "300963539770",
    appId: "1:300963539770:web:aef62afe97ed487373be03"
};
```

### 3. Python Firebase Admin SDK Setup

1. Install Python 3.7 or higher
2. Install required packages:
   ```bash
   pip install firebase-admin
   ```
3. Ensure Python script is executable:
   ```bash
   chmod +x verify_token_admin.py
   ```
4. **Test the setup**:
   ```bash
   python3 -c "import firebase_admin; print('✅ Firebase Admin SDK installed successfully!')"
   ```

### 4. File Configuration

1. Update `config/db.php` with your database credentials if different from default
2. Add course images to `assets/images/` directory:
   - html.jpg
   - css.jpg
   - javascript.jpg
   - advanced-js.jpg
   - fullstack.jpg
   - ml.jpg

### 5. Deploy the Application

1. Place the entire `skill_academy` folder in your XAMPP htdocs directory
2. Access the application at `http://localhost/skill_academy/`

## 🔧 Firebase Admin SDK Integration

The application now uses the **Firebase Admin SDK for Python** for secure token verification:

### How It Works:
1. **Frontend**: Firebase JavaScript SDK handles authentication
2. **Backend**: Python script with Admin SDK verifies tokens
3. **PHP**: Calls Python script for token validation
4. **Database**: User data stored securely in MySQL

### Files Involved:
- `verify_token_admin.py` - Python Admin SDK verification
- `verify_token.php` - PHP wrapper for Python script
- `register_firebase_handler.php` - Registration with token verification
- `login_firebase_handler.php` - Login with token verification
- `requirements.txt` - Python dependencies

## 🎯 How It Works

### User Registration & Login

1. Users register with email and password via Firebase Authentication
2. Firebase ID tokens are verified on the backend
3. User data is stored in MySQL database with Firebase UID

### Course Access System

1. **Basic Courses**: Available to all registered users
2. **Advanced Courses**: Require:
   - Completion of ALL basic courses
   - Active premium membership

### Learning Progression

1. Users enroll in courses and track progress
2. Basic courses must be completed before advanced access
3. Premium membership unlocks advanced content
4. Progress is saved and displayed on dashboard

## 🔐 Security Features

- Firebase ID token verification
- Prepared statements for MySQL queries
- Input sanitization and output escaping
- Session management
- Protected routes for authenticated users
- Prevention of direct course access

## 📱 Responsive Design

The application features a fully responsive design that works on:
- Desktop computers
- Tablets
- Mobile phones

## 🎨 UI Features

- Modern, clean interface
- Smooth animations and transitions
- Interactive course cards
- Progress tracking visualization
- Premium membership badges
- Locked course indicators
- Mobile-friendly navigation

## 🔄 User Flow

1. **Registration** → Create account with email/password
2. **Login** → Access dashboard and courses
3. **Browse Courses** → View available courses on homepage
4. **Enroll** → Start learning basic courses
5. **Complete Basics** → Finish all basic courses
6. **Upgrade to Premium** → Unlock advanced courses
7. **Advanced Learning** → Access premium content
8. **Track Progress** → Monitor completion status

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Ensure XAMPP MySQL is running
   - Check database credentials in `config/db.php`
   - Verify database exists and tables are created

2. **Firebase Authentication Error**
   - Check Firebase configuration in `firebase_config.js`
   - Ensure Email/Password authentication is enabled
   - Verify API keys are correct

3. **Course Images Not Showing**
   - Add images to `assets/images/` directory
   - Check file names match database entries
   - Verify image permissions

4. **Session Issues**
   - Ensure browser cookies are enabled
   - Check PHP session settings
   - Verify session storage path permissions

## 📝 Notes

- This is a demonstration application
- Payment processing for premium membership is simulated
- In production, implement proper Firebase Admin SDK for token verification
- Add real payment processing for premium features
- Implement additional security measures for production

## 🤝 Contributing

Feel free to extend and improve this application:
- Add more courses and categories
- Implement video content
- Add user profiles and avatars
- Implement certificates of completion
- Add social features and forums

## 📄 License

This project is for educational purposes. Feel free to use and modify as needed.

## 📞 Support

For issues and questions:
1. Check the troubleshooting section
2. Verify all setup steps are completed
3. Ensure all prerequisites are met

---

**Happy Learning! 🎓**
