#!/usr/bin/env python3
"""
Firebase Admin SDK Token Verification
This script verifies Firebase ID tokens using the Firebase Admin SDK
"""

import firebase_admin
from firebase_admin import credentials
from firebase_admin import auth
import json
import sys

def verify_firebase_token(id_token):
    """
    Verify Firebase ID token using Admin SDK
    
    Args:
        id_token (str): Firebase ID token to verify
        
    Returns:
        dict: User data if token is valid, None otherwise
    """
    try:
        # Initialize Firebase Admin SDK if not already initialized
        if not firebase_admin._apps:
            cred = credentials.Certificate("config/firebase_credentials.json")
            firebase_admin.initialize_app(cred)
        
        # Verify the ID token
        decoded_token = auth.verify_id_token(id_token)
        
        # Extract user information
        user_data = {
            'uid': decoded_token['uid'],
            'email': decoded_token['email'],
            'name': decoded_token.get('name', decoded_token['email']),
            'email_verified': decoded_token.get('email_verified', False),
            'iss': decoded_token['iss'],
            'aud': decoded_token['aud']
        }
        
        return user_data
        
    except Exception as e:
        print(f"Token verification error: {str(e)}", file=sys.stderr)
        return None

if __name__ == "__main__":
    # Read token from command line argument or stdin
    if len(sys.argv) > 1:
        id_token = sys.argv[1]
    else:
        id_token = sys.stdin.read().strip()
    
    if not id_token:
        print(json.dumps({'success': False, 'message': 'No token provided'}))
        sys.exit(1)
    
    # Verify the token
    user_data = verify_firebase_token(id_token)
    
    if user_data:
        print(json.dumps({'success': True, 'user': user_data}))
    else:
        print(json.dumps({'success': False, 'message': 'Invalid token'}))
        sys.exit(1)
