<?php
require_once 'config/db.php';
require_once 'config/auth.php';

// Get token from URL
$token = $_GET['token'] ?? '';

if (empty($token)) {
    header('Location: login.php');
    exit;
}

// Verify token
$stmt = $conn->prepare("
    SELECT pr.user_id, pr.expires_at, u.email 
    FROM password_resets pr 
    JOIN users u ON pr.user_id = u.id 
    WHERE pr.token = ? AND pr.expires_at > NOW()
");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $error = 'Invalid or expired reset token';
} else {
    $resetData = $result->fetch_assoc();
    $userId = $resetData['user_id'];
    $userEmail = $resetData['email'];
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($userId)) {
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    
    // CSRF protection
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request token';
    } elseif (empty($password) || empty($confirmPassword)) {
        $error = 'All fields are required';
    } elseif (!validatePassword($password)) {
        $error = 'Password must be at least 8 characters with at least 1 letter and 1 number';
    } elseif ($password !== $confirmPassword) {
        $error = 'Passwords do not match';
    } else {
        // Hash new password
        $passwordHash = hashPassword($password);
        
        // Update user password
        $updateStmt = $conn->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
        $updateStmt->bind_param("si", $passwordHash, $userId);
        
        if ($updateStmt->execute()) {
            // Delete reset token
            $deleteStmt = $conn->prepare("DELETE FROM password_resets WHERE token = ?");
            $deleteStmt->bind_param("s", $token);
            $deleteStmt->execute();
            
            // Log password reset
            error_log("Password reset completed for user ID: {$userId}");
            
            $success = 'Password has been reset successfully. You can now login with your new password.';
            
            // Redirect to login after 3 seconds
            header("refresh:3;url=login.php");
        } else {
            $error = 'Failed to reset password. Please try again.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Skill Academy</title>
    <link rel="stylesheet" href="assets/css/auth.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <h1>Skill Academy</h1>
                <p>Reset your password</p>
            </div>
            
            <?php if (isset($error)): ?>
                <div class="auth-message error" style="margin-bottom: 20px;">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($success)): ?>
                <div class="auth-message success" style="margin-bottom: 20px;">
                    <?php echo htmlspecialchars($success); ?>
                </div>
                <p style="text-align: center; margin-top: 20px;">
                    <a href="login.php" class="btn btn-primary">Go to Login</a>
                </p>
            <?php elseif (isset($userId)): ?>
                <form id="resetForm" class="auth-form" method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" value="<?php echo htmlspecialchars($userEmail); ?>" readonly style="background-color: #f8f9fa;">
                        <small style="color: #666; font-size: 12px;">Email cannot be changed</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">New Password</label>
                        <input type="password" id="password" name="password" placeholder="Enter your new password" required minlength="8" onkeyup="checkPasswordStrength(this.value)">
                        <div class="password-strength">
                            <div class="password-strength-bar" id="passwordStrengthBar"></div>
                        </div>
                        <small style="color: #666; font-size: 12px;">Minimum 8 characters with letters and numbers</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">Confirm New Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm your new password" required>
                        <small style="color: #666; font-size: 12px;">Re-enter your new password</small>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Reset Password</button>
                </form>
            <?php else: ?>
                <p style="text-align: center;">
                    <a href="login.php" class="btn btn-primary">Back to Login</a>
                </p>
            <?php endif; ?>
        </div>
    </div>
    
    <?php if (isset($userId) && !isset($success)): ?>
    <script>
        function checkPasswordStrength(password) {
            const strengthBar = document.getElementById('passwordStrengthBar');
            let strength = 0;
            
            if (password.length >= 8) strength++;
            if (password.length >= 12) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[a-z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            
            strengthBar.className = 'password-strength-bar';
            
            if (strength <= 2) {
                strengthBar.classList.add('strength-weak');
            } else if (strength <= 4) {
                strengthBar.classList.add('strength-medium');
            } else {
                strengthBar.classList.add('strength-strong');
            }
        }
        
        // Form validation
        document.getElementById('resetForm').addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Passwords do not match');
                return false;
            }
            
            if (password.length < 8 || !/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) {
                e.preventDefault();
                alert('Password must be at least 8 characters with letters and numbers');
                return false;
            }
        });
        
        // Real-time password confirmation validation
        document.getElementById('confirm_password').addEventListener('input', function() {
            const password = document.getElementById('password').value;
            const confirmPassword = this.value;
            
            if (confirmPassword && password !== confirmPassword) {
                this.style.borderColor = '#dc3545';
            } else if (confirmPassword && password === confirmPassword) {
                this.style.borderColor = '#28a745';
            } else {
                this.style.borderColor = '#e1e5e9';
            }
        });
    </script>
    <?php endif; ?>
</body>
</html>
