-- Skill Academy Database Schema
-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS skill_academy;
USE skill_academy;

-- Create users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    firebase_uid VARCHAR(255) UNIQUE,
    name VARCHAR(100),
    email VARCHAR(150),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create courses table
CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    level ENUM('basic','advanced') DEFAULT 'basic',
    image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create enrollments table
CREATE TABLE enrollments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    course_id INT,
    completed BOOLEAN DEFAULT 0,
    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    UNIQUE KEY unique_enrollment (user_id, course_id)
);

-- Create premium_memberships table
CREATE TABLE premium_memberships (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    activated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_premium (user_id)
);

-- Insert sample courses
INSERT INTO courses (title, description, level, image) VALUES
('HTML Fundamentals', 'Learn the basics of HTML including tags, attributes, semantic HTML, and best practices for web development.', 'basic', 'html.jpg'),
('CSS Mastery', 'Master CSS styling, layouts, animations, and responsive design techniques to create beautiful web interfaces.', 'basic', 'css.jpg'),
('JavaScript Basics', 'Understand JavaScript fundamentals including variables, functions, DOM manipulation, and event handling.', 'basic', 'javascript.jpg'),
('Advanced JavaScript', 'Deep dive into advanced JavaScript concepts including closures, promises, async/await, and modern ES6+ features.', 'advanced', 'advanced-js.jpg'),
('Full Stack Development', 'Learn complete web development with frontend and backend technologies, databases, and deployment strategies.', 'advanced', 'fullstack.jpg'),
('Machine Learning Foundations', 'Introduction to machine learning concepts, algorithms, and practical applications using Python and popular libraries.', 'advanced', 'ml.jpg');

-- Create indexes for better performance
CREATE INDEX idx_users_firebase_uid ON users(firebase_uid);
CREATE INDEX idx_enrollments_user_id ON enrollments(user_id);
CREATE INDEX idx_enrollments_course_id ON enrollments(course_id);
CREATE INDEX idx_courses_level ON courses(level);
CREATE INDEX idx_premium_user_id ON premium_memberships(user_id);
