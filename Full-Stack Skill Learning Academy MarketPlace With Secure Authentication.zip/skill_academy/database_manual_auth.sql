-- Updated Database Schema for Manual Authentication
-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS skill_academy;
USE skill_academy;

-- Update users table for manual authentication
ALTER TABLE users 
ADD COLUMN password_hash VARCHAR(255) AFTER email,
ADD COLUMN email_verified BOOLEAN DEFAULT FALSE AFTER password_hash,
ADD COLUMN verification_token VARCHAR(255) AFTER email_verified,
ADD COLUMN reset_token VARCHAR(255) AFTER verification_token,
ADD COLUMN reset_expires DATETIME AFTER reset_token,
ADD COLUMN last_login DATETIME AFTER reset_expires,
ADD COLUMN login_attempts INT DEFAULT 0 AFTER last_login,
ADD COLUMN locked_until DATETIME AFTER login_attempts,
ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- Create password reset tokens table
CREATE TABLE password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    token VARCHAR(255) UNIQUE,
    expires_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create login attempts table for security
CREATE TABLE login_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(150),
    ip_address VARCHAR(45),
    user_agent TEXT,
    success BOOLEAN,
    attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_ip (ip_address),
    INDEX idx_attempted_at (attempted_at)
);

-- Create user sessions table for enhanced security
CREATE TABLE user_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    session_id VARCHAR(255) UNIQUE,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_session_id (session_id),
    INDEX idx_user_id (user_id),
    INDEX idx_expires_at (expires_at)
);

-- Update existing courses table if needed
-- (courses table should already exist from previous setup)

-- Update existing enrollments table if needed
-- (enrollments table should already exist from previous setup)

-- Update existing premium_memberships table if needed
-- (premium_memberships table should already exist from previous setup)

-- Insert sample courses (if not already present)
INSERT IGNORE INTO courses (title, description, level, image) VALUES
('HTML Fundamentals', 'Learn the basics of HTML including tags, attributes, semantic HTML, and best practices for web development.', 'basic', 'html.jpg'),
('CSS Mastery', 'Master CSS styling, layouts, animations, and responsive design techniques to create beautiful web interfaces.', 'basic', 'css.jpg'),
('JavaScript Basics', 'Understand JavaScript fundamentals including variables, functions, DOM manipulation, and event handling.', 'basic', 'javascript.jpg'),
('Advanced JavaScript', 'Deep dive into advanced JavaScript concepts including closures, promises, async/await, and modern ES6+ features.', 'advanced', 'advanced-js.jpg'),
('Full Stack Development', 'Learn complete web development with frontend and backend technologies, databases, and deployment strategies.', 'advanced', 'fullstack.jpg'),
('Machine Learning Foundations', 'Introduction to machine learning concepts, algorithms, and practical applications using Python and popular libraries.', 'advanced', 'ml.jpg');

-- Create indexes for better performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_verification_token ON users(verification_token);
CREATE INDEX idx_users_reset_token ON users(reset_token);
CREATE INDEX idx_enrollments_user_id ON enrollments(user_id);
CREATE INDEX idx_enrollments_course_id ON enrollments(course_id);
CREATE INDEX idx_courses_level ON courses(level);
CREATE INDEX idx_premium_user_id ON premium_memberships(user_id);

-- Create a sample admin user (password: admin123)
INSERT IGNORE INTO users (name, email, password_hash, email_verified) VALUES
('Admin User', 'admin@skillacademy.com', '$2y$12$92rUNoEaV7I8NJ8ed7w7C.9UjQj8q8q8q8q8q8q8q8q8q8q8q8q8q8q8q8q8q8q8q8q8q8', TRUE);

-- Create a sample regular user (password: user123)
INSERT IGNORE INTO users (name, email, password_hash, email_verified) VALUES
('Test User', 'user@skillacademy.com', '$2y$12$92rUNoEaV7I8NJ8ed7w7C.9UjQj8q8q8q8q8q8q8q8q8q8q8q8q8q8q8q8q8q8q8q8q8q8', TRUE);

-- Note: The above passwords are hashed versions of 'admin123' and 'user123'
-- In production, you should generate proper hashes using the hashPassword() function
