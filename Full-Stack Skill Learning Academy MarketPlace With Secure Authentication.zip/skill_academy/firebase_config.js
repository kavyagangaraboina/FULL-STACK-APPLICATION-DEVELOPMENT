// Firebase Configuration - Modern ES6 Modules
// Import functions you need from SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.10.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, updateProfile, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.10.0/firebase-auth.js";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyA70mBz8uH5fQ1Agvc_3jBDxpL3g1v_7yU",
    authDomain: "skill-academy1.firebaseapp.com",
    projectId: "skill-academy1",
    storageBucket: "skill-academy1.firebasestorage.app",
    messagingSenderId: "300963539770",
    appId: "1:300963539770:web:aef62afe97ed487373be03"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Export for use in other scripts
window.firebaseApp = app;
window.firebaseAuth = auth;

// Helper functions for UI feedback
function showLoadingState(show) {
    const submitButtons = document.querySelectorAll('button[type="submit"]');
    submitButtons.forEach(button => {
        if (show) {
            button.disabled = true;
            button.textContent = 'Loading...';
        } else {
            button.disabled = false;
            // Restore original text
            const form = button.closest('form');
            if (form && form.id === 'loginForm') {
                button.textContent = 'Sign In';
            } else if (form && form.id === 'registerForm') {
                button.textContent = 'Create Account';
            }
        }
    });
}

function showSuccessMessage(message) {
    showMessage(message, 'success');
}

function showErrorMessage(message) {
    showMessage(message, 'error');
}

function showMessage(message, type) {
    // Remove any existing messages
    const existingMessage = document.querySelector('.auth-message');
    if (existingMessage) {
        existingMessage.remove();
    }
    
    // Create message element
    const messageDiv = document.createElement('div');
    messageDiv.className = `auth-message ${type}`;
    messageDiv.textContent = message;
    
    // Style the message
    messageDiv.style.cssText = `
        padding: 12px 16px;
        margin: 10px 0;
        border-radius: 6px;
        text-align: center;
        font-weight: 500;
        ${type === 'success' ? 
            'background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb;' : 
            'background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb;'
        }
    `;
    
    // Insert message after the form
    const form = document.querySelector('form');
    if (form) {
        form.parentNode.insertBefore(messageDiv, form.nextSibling);
    }
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.remove();
        }
    }, 5000);
}

// DOM elements
const registerForm = document.getElementById('registerForm');
const loginForm = document.getElementById('loginForm');
const logoutBtn = document.getElementById('logoutBtn');

// Register function
async function register(email, password, name) {
    try {
        // Show loading state
        showLoadingState(true);
        
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        
        // Update user profile with name
        await updateProfile(user, {
            displayName: name
        });
        
        // Send user data to backend
        const idToken = await user.getIdToken();
        const response = await fetch('register_firebase_handler.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                idToken: idToken,
                name: name,
                email: email
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Store session data with all user information
            const sessionData = {
                id: result.user.id,
                firebase_uid: result.user.firebase_uid,
                name: result.user.name,
                email: result.user.email,
                has_premium: result.user.has_premium || false,
                login_time: new Date().toISOString()
            };
            
            sessionStorage.setItem('userSession', JSON.stringify(sessionData));
            
            // Show success message
            showSuccessMessage('Registration successful! Redirecting to dashboard...');
            
            // Redirect to dashboard
            setTimeout(() => {
                window.location.href = 'dashboard.php';
            }, 1500);
        } else {
            throw new Error(result.message);
        }
        
    } catch (error) {
        console.error('Registration error:', error);
        
        // Handle specific Firebase errors
        let errorMessage = 'Registration failed';
        
        if (error.code === 'auth/email-already-in-use') {
            errorMessage = 'This email is already registered. Redirecting to login page...';
            const email = document.getElementById('email').value;
            setTimeout(() => {
                window.location.href = `login_firebase.php?email=${encodeURIComponent(email)}&message=${encodeURIComponent('This email is already registered. Please login below.')}`;
            }, 2000);
        } else if (error.code === 'auth/weak-password') {
            errorMessage = 'Password is too weak. Please choose a stronger password.';
        } else if (error.code === 'auth/invalid-email') {
            errorMessage = 'Invalid email address. Please check and try again.';
        } else if (error.code === 'auth/network-request-failed') {
            errorMessage = 'Network error. Please check your internet connection.';
        } else {
            errorMessage = 'Registration failed: ' + error.message;
        }
        
        showErrorMessage(errorMessage);
    } finally {
        showLoadingState(false);
    }
}

// Login function
async function login(email, password) {
    try {
        // Show loading state
        showLoadingState(true);
        
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        
        // Get ID token and verify with backend
        const idToken = await user.getIdToken();
        const response = await fetch('login_firebase_handler.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                idToken: idToken
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Store session data with all user information
            const sessionData = {
                id: result.user.id,
                firebase_uid: result.user.firebase_uid,
                name: result.user.name,
                email: result.user.email,
                has_premium: result.user.has_premium || false,
                login_time: new Date().toISOString()
            };
            
            sessionStorage.setItem('userSession', JSON.stringify(sessionData));
            
            // Show success message
            showSuccessMessage('Login successful! Redirecting to dashboard...');
            
            // Redirect to dashboard
            setTimeout(() => {
                window.location.href = 'dashboard.php';
            }, 1500);
        } else {
            throw new Error(result.message);
        }
        
    } catch (error) {
        console.error('Login error:', error);
        
        // Handle specific Firebase errors
        let errorMessage = 'Login failed';
        
        if (error.code === 'auth/user-not-found') {
            errorMessage = 'No account found with this email. Please register first.';
        } else if (error.code === 'auth/wrong-password') {
            errorMessage = 'Incorrect password. Please try again.';
        } else if (error.code === 'auth/invalid-email') {
            errorMessage = 'Invalid email address. Please check and try again.';
        } else if (error.code === 'auth/user-disabled') {
            errorMessage = 'This account has been disabled. Please contact support.';
        } else if (error.code === 'auth/too-many-requests') {
            errorMessage = 'Too many failed attempts. Please try again later.';
        } else if (error.code === 'auth/network-request-failed') {
            errorMessage = 'Network error. Please check your internet connection.';
        } else {
            errorMessage = 'Login failed: ' + error.message;
        }
        
        showErrorMessage(errorMessage);
    } finally {
        showLoadingState(false);
    }
}

// Logout function
async function logout() {
    try {
        await signOut(auth);
        
        // Clear session and redirect
        sessionStorage.removeItem('userSession');
        window.location.href = 'login_firebase.php';
        
    } catch (error) {
        console.error('Logout error:', error);
        alert('Logout failed: ' + error.message);
    }
}

// Event listeners
if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        await register(email, password, name);
    });
}

if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        await login(email, password);
    });
}

if (logoutBtn) {
    logoutBtn.addEventListener('click', logout);
}

// Check authentication state and handle URL parameters
onAuthStateChanged(auth, async (user) => {
    if (user) {
        // User is signed in
        const idToken = await user.getIdToken();
        // You can use this token for backend verification if needed
    } else {
        // User is signed out
        const currentPage = window.location.pathname.split('/').pop();
        const protectedPages = ['dashboard.php', 'premium.php'];
        
        if (protectedPages.includes(currentPage)) {
            window.location.href = 'login_firebase.php';
        }
    }
    
    // Handle URL parameters for better UX
    const urlParams = new URLSearchParams(window.location.search);
    
    // Pre-fill email if coming from registration error
    if (urlParams.has('email')) {
        const emailField = document.getElementById('email');
        if (emailField) {
            emailField.value = urlParams.get('email');
        }
    }
    
    // Show message if redirected from registration
    if (urlParams.has('message')) {
        const message = urlParams.get('message');
        if (message) {
            // Create a nice message element instead of alert
            const messageDiv = document.createElement('div');
            messageDiv.style.cssText = `
                background-color: #d1ecf1;
                border: 1px solid #bee5eb;
                color: #0c5460;
                padding: 10px;
                margin: 10px 0;
                border-radius: 5px;
                text-align: center;
            `;
            messageDiv.textContent = decodeURIComponent(message);
            
            // Insert at the top of the auth-container
            const authContainer = document.querySelector('.auth-container');
            if (authContainer) {
                authContainer.insertBefore(messageDiv, authContainer.firstChild);
            }
        }
    }
});
