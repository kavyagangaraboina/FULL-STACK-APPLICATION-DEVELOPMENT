<?php
require_once 'config/db.php';
require_once 'config/auth.php';

header('Content-Type: application/json');

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get and validate input
$email = sanitizeInput($_POST['email'] ?? '');

// CSRF protection
if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    echo json_encode(['success' => false, 'message' => 'Invalid request token']);
    exit;
}

// Rate limiting
if (!checkRateLimit('reset_' . $email)) {
    echo json_encode(['success' => false, 'message' => 'Too many reset attempts. Please try again later.']);
    exit;
}

// Validate input
if (empty($email)) {
    echo json_encode(['success' => false, 'message' => 'Email address is required']);
    exit;
}

if (!validateEmail($email)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email address']);
    exit;
}

try {
    // Check if user exists
    $stmt = $conn->prepare("SELECT id, name FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        // Don't reveal if email exists or not
        echo json_encode(['success' => true, 'message' => 'If an account with that email exists, a password reset link has been sent.']);
        exit;
    }
    
    $user = $result->fetch_assoc();
    
    // Generate reset token
    $resetToken = bin2hex(random_bytes(32));
    $expiresAt = date('Y-m-d H:i:s', time() + 3600); // 1 hour expiry
    
    // Save reset token
    $tokenStmt = $conn->prepare("
        INSERT INTO password_resets (user_id, token, expires_at) 
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE 
        token = VALUES(token),
        expires_at = VALUES(expires_at)
    ");
    $tokenStmt->bind_param("iss", $user['id'], $resetToken, $expiresAt);
    $tokenStmt->execute();
    
    // In a real application, you would send an email here
    // For demo purposes, we'll just return success
    $resetLink = "http://localhost/skill_academy/reset_password.php?token=" . $resetToken;
    
    // Log the reset request (in production, you'd email this)
    error_log("Password reset link for {$email}: {$resetLink}");
    
    echo json_encode([
        'success' => true, 
        'message' => 'Password reset link has been sent to your email address.',
        'debug_link' => $resetLink // Remove this in production
    ]);
    
} catch (Exception $e) {
    error_log("Password reset error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred. Please try again.']);
}

$stmt->close();
$conn->close();
?>
