<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Skill Academy</title>
    <link rel="stylesheet" href="assets/css/auth.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <h1>Skill Academy</h1>
                <p>Reset your password</p>
            </div>
            
            <form id="forgotForm" class="auth-form" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email address" required>
                    <small style="color: #666; font-size: 12px;">We'll send a reset link to your email</small>
                </div>
                
                <button type="submit" class="btn btn-primary">Send Reset Link</button>
            </form>
            
            <div class="auth-footer">
                <p>Remember your password? <a href="login.php">Sign In</a></p>
                <p>Don't have an account? <a href="register.php">Sign Up</a></p>
            </div>
        </div>
    </div>
    
    <script>
        // Form submission handler
        document.getElementById('forgotForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Clear previous messages
            const existingMessage = document.querySelector('.auth-message');
            if (existingMessage) {
                existingMessage.remove();
            }
            
            // Get form data
            const formData = new FormData(this);
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            
            // Show loading state
            submitBtn.disabled = true;
            submitBtn.textContent = 'Sending...';
            
            try {
                const response = await fetch('forgot_password_handler.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showMessage(result.message, 'success');
                    
                    // Show debug link in development (remove in production)
                    if (result.debug_link) {
                        console.log('Debug reset link:', result.debug_link);
                        showMessage('Check console for reset link (development only)', 'info');
                    }
                    
                    // Reset form
                    this.reset();
                    
                    // Redirect to login after 3 seconds
                    setTimeout(() => {
                        window.location.href = 'login.php';
                    }, 3000);
                } else {
                    showMessage(result.message, 'error');
                }
            } catch (error) {
                console.error('Forgot password error:', error);
                showMessage('An error occurred. Please try again.', 'error');
            } finally {
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            }
        });
        
        function showMessage(message, type) {
            // Remove any existing messages
            const existingMessage = document.querySelector('.auth-message');
            if (existingMessage) {
                existingMessage.remove();
            }
            
            // Create message element
            const messageDiv = document.createElement('div');
            messageDiv.className = `auth-message ${type}`;
            messageDiv.textContent = message;
            
            // Style the message
            messageDiv.style.cssText = `
                padding: 12px 16px;
                margin: 15px 0;
                border-radius: 8px;
                text-align: center;
                font-weight: 500;
                ${type === 'success' ? 
                    'background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb;' : 
                    type === 'info' ?
                    'background-color: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb;' :
                    'background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb;'
                }
            `;
            
            // Insert message after the form
            const form = document.querySelector('form');
            if (form) {
                form.parentNode.insertBefore(messageDiv, form.nextSibling);
            }
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                if (messageDiv.parentNode) {
                    messageDiv.remove();
                }
            }, 5000);
        }
        
        // Auto-focus email field on page load
        document.addEventListener('DOMContentLoaded', function() {
            const emailField = document.getElementById('email');
            if (emailField) {
                emailField.focus();
            }
        });
    </script>
</body>
</html>
