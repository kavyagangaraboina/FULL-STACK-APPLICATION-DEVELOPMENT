<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Skill Academy</title>
    <link rel="stylesheet" href="assets/css/auth.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <h1>Skill Academy</h1>
                <p>Welcome back! Sign in to continue your learning journey</p>
            </div>
            
            <form id="loginForm" class="auth-form" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>
                
                <div class="form-group" style="display: flex; align-items: center; margin-bottom: 20px;">
                    <input type="checkbox" id="remember" name="remember" style="width: auto; margin-right: 8px;">
                    <label for="remember" style="margin: 0; font-weight: normal;">Remember me for 30 days</label>
                </div>
                
                <button type="submit" class="btn btn-primary">Sign In</button>
            </form>
            
            <div class="auth-footer">
                <p>Don't have an account? <a href="register.php">Sign Up</a></p>
                <p style="margin-top: 10px;"><a href="#" onclick="showPasswordReset()" style="font-size: 13px;">Forgot your password?</a></p>
            </div>
        </div>
    </div>
    
    <script>
        // Form submission handler
        document.getElementById('loginForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Clear previous messages
            const existingMessage = document.querySelector('.auth-message');
            if (existingMessage) {
                existingMessage.remove();
            }
            
            // Get form data
            const formData = new FormData(this);
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            
            // Show loading state
            submitBtn.disabled = true;
            submitBtn.textContent = 'Signing In...';
            
            try {
                const response = await fetch('login_handler.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showMessage(result.message, 'success');
                    setTimeout(() => {
                        window.location.href = 'dashboard.php';
                    }, 1500);
                } else {
                    showMessage(result.message, 'error');
                }
            } catch (error) {
                console.error('Login error:', error);
                showMessage('An error occurred. Please try again.', 'error');
            } finally {
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            }
        });
        
        function showMessage(message, type) {
            // Remove any existing messages
            const existingMessage = document.querySelector('.auth-message');
            if (existingMessage) {
                existingMessage.remove();
            }
            
            // Create message element
            const messageDiv = document.createElement('div');
            messageDiv.className = `auth-message ${type}`;
            messageDiv.textContent = message;
            
            // Style the message
            messageDiv.style.cssText = `
                padding: 12px 16px;
                margin: 15px 0;
                border-radius: 8px;
                text-align: center;
                font-weight: 500;
                ${type === 'success' ? 
                    'background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb;' : 
                    'background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb;'
                }
            `;
            
            // Insert message after the form
            const form = document.querySelector('form');
            if (form) {
                form.parentNode.insertBefore(messageDiv, form.nextSibling);
            }
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                if (messageDiv.parentNode) {
                    messageDiv.remove();
                }
            }, 5000);
        }
        
        function showPasswordReset() {
            showMessage('Password reset functionality coming soon! For now, please contact support.', 'info');
        }
        
        // Auto-focus email field on page load
        document.addEventListener('DOMContentLoaded', function() {
            const emailField = document.getElementById('email');
            if (emailField) {
                emailField.focus();
            }
            
            // Handle URL parameters for pre-filled data
            const urlParams = new URLSearchParams(window.location.search);
            
            // Pre-fill email if provided
            if (urlParams.has('email')) {
                emailField.value = urlParams.get('email');
            }
            
            // Show message if provided
            if (urlParams.has('message')) {
                const message = urlParams.get('message');
                if (message) {
                    showMessage(decodeURIComponent(message), 'info');
                }
            }
        });
        
        // Add enter key support for form submission
        document.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const form = document.getElementById('loginForm');
                if (form && document.activeElement.tagName !== 'BUTTON') {
                    form.dispatchEvent(new Event('submit'));
                }
            }
        });
    </script>
</body>
</html>
