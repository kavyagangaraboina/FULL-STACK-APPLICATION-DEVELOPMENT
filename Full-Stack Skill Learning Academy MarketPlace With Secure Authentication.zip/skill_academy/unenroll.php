<?php
session_start();
require_once 'config/db.php';

// Check if user is logged in
$userSession = isset($_SESSION['userSession']) ? $_SESSION['userSession'] : null;

if (!$userSession) {
    header('Location: login_firebase.php');
    exit;
}

$currentUser = json_decode($userSession, true);

// Get course ID from URL
if (!isset($_GET['course_id'])) {
    header('Location: dashboard.php');
    exit;
}

$courseId = intval($_GET['course_id']);

// Get course details
$stmt = $conn->prepare("SELECT * FROM courses WHERE id = ?");
$stmt->bind_param("i", $courseId);
$stmt->execute();
$courseResult = $stmt->get_result();

if ($courseResult->num_rows === 0) {
    header('Location: dashboard.php');
    exit;
}

$course = $courseResult->fetch_assoc();

// Check if user is enrolled in this course
$stmt = $conn->prepare("SELECT * FROM enrollments WHERE user_id = ? AND course_id = ?");
$stmt->bind_param("ii", $currentUser['id'], $courseId);
$stmt->execute();
$enrollmentResult = $stmt->get_result();

if ($enrollmentResult->num_rows === 0) {
    // Not enrolled, redirect to dashboard
    header('Location: dashboard.php');
    exit;
}

// Handle unenrollment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['unenroll'])) {
    $stmt = $conn->prepare("DELETE FROM enrollments WHERE user_id = ? AND course_id = ?");
    $stmt->bind_param("ii", $currentUser['id'], $courseId);
    
    if ($stmt->execute()) {
        $_SESSION['success_message'] = 'You have been unenrolled from ' . htmlspecialchars($course['title']) . '!';
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Failed to unenroll from course. Please try again.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unenroll from Course - Skill Academy</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Firebase SDK -->
    <script src="https://www.gstatic.com/firebasejs/9.6.1/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.6.1/firebase-auth-compat.js"></script>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-brand">
                <h1>Skill Academy</h1>
            </div>
            <div class="nav-menu">
                <span class="nav-user">Welcome, <?php echo htmlspecialchars($currentUser['name']); ?></span>
                <a href="dashboard.php" class="nav-link">Dashboard</a>
                <a href="index.php" class="nav-link">Home</a>
                <button id="logoutBtn" class="btn btn-outline">Logout</button>
            </div>
        </div>
    </nav>

    <!-- Unenrollment Section -->
    <section class="unenrollment-section">
        <div class="container">
            <div class="unenrollment-card">
                <div class="course-preview">
                    <div class="course-image">
                        <img src="assets/images/<?php echo htmlspecialchars($course['image']); ?>" alt="<?php echo htmlspecialchars($course['title']); ?>">
                    </div>
                    
                    <div class="course-info">
                        <h2><?php echo htmlspecialchars($course['title']); ?></h2>
                        <p class="course-description"><?php echo htmlspecialchars($course['description']); ?></p>
                        
                        <div class="course-meta">
                            <span class="course-level <?php echo $course['level']; ?>">
                                <?php echo ucfirst($course['level']); ?> Course
                            </span>
                            <span class="enrolled-badge">Currently Enrolled</span>
                        </div>
                    </div>
                </div>

                <div class="unenrollment-content">
                    <h3>⚠️ Are you sure you want to unenroll?</h3>
                    
                    <?php if (isset($error)): ?>
                        <div class="message error">
                            <?php echo htmlspecialchars($error); ?>
                        </div>
                    <?php endif; ?>

                    <div class="unenrollment-warning">
                        <h4>Before you unenroll, please note:</h4>
                        <ul>
                            <li>📊 All your progress in this course will be lost</li>
                            <li>🏆 Any completion status will be removed</li>
                            <li>📚 You will need to enroll again to continue learning</li>
                            <li>💡 If you need a break, consider pausing instead</li>
                        </ul>
                    </div>

                    <div class="unenrollment-options">
                        <div class="option-card">
                            <h4>🔄 Want to take a break?</h4>
                            <p>You can keep your enrollment and return to the course anytime. Your progress will be saved.</p>
                            <a href="dashboard.php" class="btn btn-outline">Keep Enrollment</a>
                        </div>
                        
                        <div class="option-card danger">
                            <h4>❌ Remove course completely?</h4>
                            <p>This will permanently delete your enrollment and all progress in this course.</p>
                            <form method="POST" class="unenrollment-form">
                                <button type="submit" name="unenroll" class="btn btn-danger btn-large">
                                    Yes, Unenroll Me
                                </button>
                            </form>
                        </div>
                    </div>

                    <div class="unenrollment-note">
                        <p><strong>Need help?</strong> If you're having technical issues or need assistance, consider contacting support before unenrolling.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <style>
        .unenrollment-section {
            padding: 2rem 0;
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .unenrollment-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            max-width: 800px;
            margin: 0 auto;
        }

        .course-preview {
            display: flex;
            gap: 2rem;
            padding: 2rem;
            background: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
        }

        .course-image img {
            width: 150px;
            height: 100px;
            object-fit: cover;
            border-radius: 8px;
        }

        .unenrollment-content {
            padding: 2rem;
        }

        .unenrollment-warning {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 1.5rem;
            margin: 1.5rem 0;
        }

        .unenrollment-warning h4 {
            color: #856404;
            margin-bottom: 1rem;
        }

        .unenrollment-warning ul {
            color: #856404;
            margin: 0;
            padding-left: 1.5rem;
        }

        .unenrollment-options {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            margin: 2rem 0;
        }

        .option-card {
            border: 2px solid #e9ecef;
            border-radius: 8px;
            padding: 1.5rem;
            text-align: center;
        }

        .option-card.danger {
            border-color: #dc3545;
            background: #fff5f5;
        }

        .option-card h4 {
            margin-bottom: 0.5rem;
        }

        .option-card p {
            color: #6c757d;
            margin-bottom: 1rem;
        }

        .btn-danger {
            background: #dc3545;
            color: white;
            border: none;
            padding: 0.75rem 2rem;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            transition: background 0.3s;
        }

        .btn-danger:hover {
            background: #c82333;
        }

        .btn-large {
            padding: 1rem 2rem;
            font-size: 1.1rem;
        }

        .unenrollment-note {
            background: #e3f2fd;
            border: 1px solid #bbdefb;
            border-radius: 8px;
            padding: 1rem;
            margin-top: 1.5rem;
            text-align: center;
        }

        @media (max-width: 768px) {
            .course-preview {
                flex-direction: column;
            }
            
            .unenrollment-options {
                grid-template-columns: 1fr;
            }
        }
    </style>

    <script src="firebase_config.js"></script>
</body>
</html>
