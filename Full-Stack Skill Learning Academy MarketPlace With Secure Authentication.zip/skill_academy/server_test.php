<?php
// Server Test File
// This file helps diagnose Apache/PHP setup issues

echo "<h1>Apache & PHP Test</h1>";

// Check PHP version
echo "<h2>PHP Information</h2>";
echo "<p><strong>PHP Version:</strong> " . phpversion() . "</p>";

// Check Apache modules
echo "<h2>Apache Modules</h2>";
if (function_exists('apache_get_modules')) {
    $modules = apache_get_modules();
    echo "<p><strong>Loaded Modules:</strong></p><ul>";
    foreach ($modules as $module) {
        echo "<li>" . htmlspecialchars($module) . "</li>";
    }
    echo "</ul>";
} else {
    echo "<p>Cannot retrieve Apache modules information</p>";
}

// Check file permissions
echo "<h2>File Permissions</h2>";
$testFile = __FILE__;
echo "<p><strong>Current File:</strong> " . $testFile . "</p>";
echo "<p><strong>Readable:</strong> " . (is_readable($testFile) ? "Yes" : "No") . "</p>";
echo "<p><strong>Writable:</strong> " . (is_writable($testFile) ? "Yes" : "No") . "</p>";

// Check current directory
echo "<h2>Directory Information</h2>";
$currentDir = getcwd();
echo "<p><strong>Current Directory:</strong> " . $currentDir . "</p>";
echo "<p><strong>Document Root:</strong> " . $_SERVER['DOCUMENT_ROOT'] . "</p>";
echo "<p><strong>Script Name:</strong> " . $_SERVER['SCRIPT_NAME'] . "</p>";
echo "<p><strong>Request URI:</strong> " . $_SERVER['REQUEST_URI'] . "</p>";

// Check database connection
echo "<h2>Database Connection Test</h2>";
try {
    $conn = new mysqli('localhost', 'root', '', 'skill_academy');
    if ($conn->connect_error) {
        echo "<p><strong>Database Connection:</strong> Failed - " . htmlspecialchars($conn->connect_error) . "</p>";
    } else {
        echo "<p><strong>Database Connection:</strong> Success</p>";
        
        // Check if tables exist
        $result = $conn->query("SHOW TABLES");
        if ($result->num_rows > 0) {
            echo "<p><strong>Tables in skill_academy:</strong></p><ul>";
            while ($row = $result->fetch_array()) {
                echo "<li>" . htmlspecialchars($row[0]) . "</li>";
            }
            echo "</ul>";
        } else {
            echo "<p><strong>Tables:</strong> No tables found. Please import database.sql</p>";
        }
        $conn->close();
    }
} catch (Exception $e) {
    echo "<p><strong>Database Connection:</strong> Error - " . htmlspecialchars($e->getMessage()) . "</p>";
}

// Check Python availability
echo "<h2>Python Test</h2>";
$pythonTest = shell_exec('python --version 2>&1');
if ($pythonTest) {
    echo "<p><strong>Python:</strong> " . htmlspecialchars(trim($pythonTest)) . "</p>";
} else {
    echo "<p><strong>Python:</strong> Not found or not in PATH</p>";
}

// Check required files
echo "<h2>Required Files Check</h2>";
$requiredFiles = [
    'firebase_config.js',
    'login_firebase.php',
    'register_firebase.php',
    'login_firebase_handler.php',
    'register_firebase_handler.php',
    'verify_token_admin.py',
    'config/firebase_credentials.json'
];

foreach ($requiredFiles as $file) {
    if (file_exists($file)) {
        echo "<p><strong>$file:</strong> ✓ Found</p>";
    } else {
        echo "<p><strong>$file:</strong> ✗ Missing</p>";
    }
}

// Server info
echo "<h2>Server Information</h2>";
echo "<p><strong>Server Software:</strong> " . htmlspecialchars($_SERVER['SERVER_SOFTWARE']) . "</p>";
echo "<p><strong>Server Name:</strong> " . htmlspecialchars($_SERVER['SERVER_NAME']) . "</p>";
echo "<p><strong>Server Port:</strong> " . $_SERVER['SERVER_PORT'] . "</p>";
echo "<p><strong>Protocol:</strong> " . htmlspecialchars($_SERVER['SERVER_PROTOCOL']) . "</p>";

echo "<hr>";
echo "<p><em>Test completed at: " . date('Y-m-d H:i:s') . "</em></p>";
?>
